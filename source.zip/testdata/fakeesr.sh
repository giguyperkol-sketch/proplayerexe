#!/bin/bash
# Stand-in for realesrgan-ncnn-vulkan (CI machines have no GPU): same command line, plain lanczos upscale.
while [ $# -gt 0 ]; do
  case "$1" in
    -i) I="$2"; shift 2;;
    -o) O="$2"; shift 2;;
    -s) S="$2"; shift 2;;
    -f) F="$2"; shift 2;;
    -n|-j|-m|-t|-g) shift 2;;
    -x|-v) shift;;
    *) echo "bad argument $1" >&2; exit 2;;
  esac
done
for f in "$I"/*.png; do
  b=$(basename "$f" .png)
  ffmpeg -loglevel error -y -i "$f" -vf "scale=iw*$S:ih*$S:flags=lanczos" -q:v 2 "$O/$b.${F:-jpg}" || exit 1
done
