# ProPlayer Studio

תוכנת העיבוד של ProPlayer FX: הגדלה ושיפור איכות לסרטונים ותמונות עם Real-ESRGAN ו-ffmpeg.
(Video / image enhancer used by the ProPlayer FX After Effects panel.)

## איך מקבלים EXE מוכן
1. מעלים את כל הקבצים האלה לריפו חדש ב-GitHub (הענף main).
2. נכנסים ללשונית **Actions**. ה-Workflow בשם **Build ProPlayer Studio** רץ לבד (או לוחצים Run workflow).
3. כשהוא מסתיים (וי ירוק), נכנסים אליו ובתחתית העמוד, תחת **Artifacts**, מורידים את **ProPlayerStudio**.
   בפנים: `ProPlayerStudio.exe` (התוכנה) ו-`ProPlayerStudio-Setup.exe` (מתקין).
4. אפשר גם ליצור Release אוטומטי: יוצרים תג בשם `v1.0.0` והקבצים יתווספו לעמוד ה-Releases.

## מה ה-Workflow עושה
- **test**: מריץ את כל הצינור האמיתי (חילוץ פריימים, הגדלה, פילטרים, ייצוא) עם ffmpeg, על כל המודלים וכל הקצוות של הסליידרים.
- **build**: בונה EXE ל-Windows, מפעיל אותו ובודק שהוא עולה ועונה, בונה את המתקין ומעלה את שניהם.

## מה השתנה בגרסה הזו
- ההגדלה והייצוא רצים **במקביל** (המקודד לוקח כל פריים ברגע שה-AI מסיים אותו) במקום אחד אחרי השני.
- ייצוא מהיר יותר: פריסט `faster` (או כרטיס NVIDIA אם יש), עיבוד ב-4:2:0, ובלי מיזוג עם המקור כשהוא זניח.
- תיקון הפרמטר הלא תקין: זמני התחלה/אורך עם סימון מדעי (למשל `4.4e-16`) הפילו את ffmpeg. עכשיו הם מנוקים תמיד.
- אם ה-AI נכשל, מופיעה הודעה אדומה עם הסיבה (ולא הגדלה רגילה בשקט).
- יומן מלא ב-`%LOCALAPPDATA%\ProPlayer Studio\studio-log.txt` עם זמנים של כל שלב והפקודות המדויקות.

## בנייה מקומית
```
go build -ldflags "-H windowsgui -s -w" -o ProPlayerStudio.exe .
```
