# ProPlayer Studio 2

תוכנת שיפור האיכות של ProPlayer FX: קליפים ותמונות פי 2, עם בינה מלאכותית (Real-ESRGAN) ו-ffmpeg.

## מצבי איכות
| מצב | מודל | מה קורה |
|---|---|---|
| מהיר | realesr-general-x4v3 | המודל של Real-ESRGAN לווידאו אמיתי. קלט בחצי גודל, פי 4, יוצא בדיוק פי 2 |
| איכות גבוהה (מומלץ) | realesr-general-x4v3 | קלט בשלושה רבעים, יוצא פי 3, ואז הקטנה נקייה לפי 2 (דגימת-על = יותר פרטים) |
| מקסימום | realesrgan-x4plus | המודל הכבד, באותה דגימת-על. הכי הרבה פרטים, איטי |
| אנימציה ומשחקים | realesr-animevideov3 | לקליפים מצוירים |

המודל realesr-general-x4v3 נמצא בתוך התוכנה (`models/`). הוא הומר ל-ncnn מהמשקלים הרשמיים של Real-ESRGAN עם `assets/pth2ncnn.py` (מיזוג 50/50 עם גרסת ה-wdn, כמו ברירת המחדל של Real-ESRGAN). הממיר נבדק מול הקובץ הרשמי של realesr-animevideov3: אותו מבנה בדיוק.

## מהירות
- ה-AI והייצוא רצים במקביל: כל פריים נכנס לייצוא ברגע שה-AI מסיים אותו.
- ייצוא בכרטיס NVIDIA כשיש, אחרת x264 מהיר. עיבוד ב-4:2:0.
- יומן מלא עם זמנים: `%LOCALAPPDATA%\ProPlayer Studio\studio-log.txt`.

## חלון
התוכנה נפתחת בחלון Windows אמיתי (WebView2, המנוע שמובנה ב-Windows 10/11): אייקון משלה, שורת כותרת כהה-זהב, בלי דפדפן.
אם WebView2 חסר במחשב, היא נפתחת בחלון אפליקציה של Edge/Chrome.
`--serve` מפעיל רק את המנוע, בלי חלון (ככה התוסף לאפטר אפקטס משתמש בו).

## בנייה ב-GitHub
בריפו צריכים להיות רק `source.zip` ו-`.github/workflows/build.yml`. ב-Actions מורידים את **ProPlayerStudio** מ-Artifacts.

## בנייה מקומית
```
go mod tidy
go build -ldflags "-H windowsgui -s -w" -o ProPlayerStudio.exe .
```
