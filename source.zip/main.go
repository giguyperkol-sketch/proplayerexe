package main

import (
	_ "embed"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

//go:embed ui.html
var uiHTML []byte

type Status struct {
	State  string `json:"state"` // idle, running, done, error
	Text   string `json:"text"`
	Pct    int    `json:"pct"`
	Out    string `json:"out"`
	Err    string `json:"err"`
	Frames int    `json:"frames"`
	Stage  int    `json:"stage"`
	Info   string `json:"info"`
	Name   string `json:"name"`
	Video  bool   `json:"video"`
	Warn   string `json:"warn"`
}

var (
	mu       sync.Mutex
	st       = Status{State: "idle"}
	lastPing = time.Now()
	pinged   bool
	cancelFn func()
)

func setSt(f func(s *Status)) { mu.Lock(); f(&st); mu.Unlock() }
func getSt() Status           { mu.Lock(); defer mu.Unlock(); return st }

func jsonOut(w http.ResponseWriter, v interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	json.NewEncoder(w).Encode(v)
}

var jobJSON = []byte("{}")

func main() {
	for i, a := range os.Args {
		if a == "--job" && i+1 < len(os.Args) {
			if b, err := os.ReadFile(os.Args[i+1]); err == nil {
				jobJSON = b
				var j Params
				if json.Unmarshal(b, &j) == nil {
					doneFile = j.Done
				}
			}
		}
	}
	os.MkdirAll(toolsDir(), 0755)
	serveOnly, portFile := false, ""
	for i, a := range os.Args {
		if a == "--serve" {
			serveOnly = true
			if i+1 < len(os.Args) && !strings.HasPrefix(os.Args[i+1], "--") {
				portFile = os.Args[i+1]
			}
		}
	}
	sharedPort := filepath.Join(toolsDir(), "port.txt")
	if serveOnly {
		// reuse a Studio server that is already running (so only one runs at a time)
		if b, err := os.ReadFile(sharedPort); err == nil {
			u := strings.TrimSpace(string(b))
			c := &http.Client{Timeout: 1500 * time.Millisecond}
			if resp, e := c.Post(u+"api/ping", "application/json", nil); e == nil {
				resp.Body.Close()
				if portFile != "" {
					os.WriteFile(portFile, []byte(u), 0644)
				}
				return
			}
		}
	}
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return
	}
	url := "http://" + ln.Addr().String() + "/"
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(uiHTML)
	})
	mux.HandleFunc("/api/ping", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		lastPing = time.Now()
		pinged = true
		mu.Unlock()
		jsonOut(w, getSt())
	})
	mux.HandleFunc("/api/job", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json; charset=utf-8")
		w.Write(jobJSON)
		jobJSON = []byte("{}")
	})
	mux.HandleFunc("/api/pick", func(w http.ResponseWriter, r *http.Request) {
		jsonOut(w, map[string]string{"path": pickFile()})
	})
	mux.HandleFunc("/api/upload", func(w http.ResponseWriter, r *http.Request) {
		name := filepath.Base(r.URL.Query().Get("name"))
		if name == "" || name == "." || name == "/" {
			name = "file"
		}
		dir := filepath.Join(toolsDir(), "uploads")
		os.RemoveAll(dir)
		os.MkdirAll(dir, 0755)
		p := filepath.Join(dir, name)
		f, err := os.Create(p)
		if err != nil {
			jsonOut(w, map[string]string{"error": "שמירה נכשלה"})
			return
		}
		io.Copy(f, r.Body)
		f.Close()
		jsonOut(w, map[string]string{"path": p})
	})
	mux.HandleFunc("/api/check", func(w http.ResponseWriter, r *http.Request) {
		var p Params
		json.NewDecoder(r.Body).Decode(&p)
		fi, err := os.Stat(p.Path)
		jsonOut(w, map[string]bool{"ok": err == nil && !fi.IsDir()})
	})
	mux.HandleFunc("/api/start", func(w http.ResponseWriter, r *http.Request) {
		var p Params
		if json.NewDecoder(r.Body).Decode(&p) != nil || p.Path == "" {
			jsonOut(w, map[string]string{"error": "no file"})
			return
		}
		if s := getSt(); s.State == "running" {
			jsonOut(w, map[string]string{"error": "busy"})
			return
		}
		if _, err := os.Stat(p.Path); err != nil {
			jsonOut(w, map[string]string{"error": "הקובץ לא נמצא"})
			return
		}
		setSt(func(s *Status) { *s = Status{State: "running", Text: "מתחיל", Name: filepath.Base(p.Path)} })
		go runJob(p)
		jsonOut(w, map[string]string{"ok": "1"})
	})
	mux.HandleFunc("/api/cancel", func(w http.ResponseWriter, r *http.Request) {
		if cancelFn != nil {
			cancelFn()
		}
		jsonOut(w, map[string]string{"ok": "1"})
	})
	mux.HandleFunc("/api/open", func(w http.ResponseWriter, r *http.Request) {
		s := getSt()
		if s.Out != "" {
			openPath(s.Out, r.URL.Query().Get("play") != "1")
		}
		jsonOut(w, map[string]string{"ok": "1"})
	})
	mux.HandleFunc("/api/quit", func(w http.ResponseWriter, r *http.Request) {
		jsonOut(w, map[string]string{"ok": "1"})
		go func() { time.Sleep(200 * time.Millisecond); shutdown() }()
	})
	mux.Handle("/pv/", http.StripPrefix("/pv/", http.FileServer(http.Dir(filepath.Join(toolsDir(), "pv")))))

	if serveOnly {
		os.WriteFile(sharedPort, []byte(url), 0644)
		if portFile != "" {
			os.WriteFile(portFile, []byte(url), 0644)
		}
	} else {
		openWindow(url)
	}
	started := time.Now()
	go func() {
		for {
			time.Sleep(3 * time.Second)
			mu.Lock()
			running := st.State == "running"
			// never quit just because the browser process handed the window to another process;
			// quit only when the page stopped pinging for a long time (or never connected)
			gone := !running && ((pinged && time.Since(lastPing) > 180*time.Second) || (!pinged && time.Since(started) > 120*time.Second))
			mu.Unlock()
			if gone {
				shutdown()
			}
		}
	}()
	http.Serve(ln, mux)
}

func shutdown() {
	if cancelFn != nil {
		cancelFn()
	}
	os.Exit(0)
}
