// ProPlayer Studio: AI video / image enhancer for the ProPlayer FX After Effects panel.
//
//	ProPlayerStudio.exe                     opens the Studio window
//	ProPlayerStudio.exe --serve [portfile]   no window: the engine behind the After Effects panel
//	ProPlayerStudio.exe --job file.json      opens the window with a job filled in
package main

import (
	"encoding/json"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const appVersion = "2.0.0"

func main() {
	serveOnly, portFile := false, ""
	for i, a := range os.Args {
		switch a {
		case "--job":
			if i+1 < len(os.Args) {
				if b, err := os.ReadFile(os.Args[i+1]); err == nil {
					jobJSON = b
					var j Params
					if json.Unmarshal(b, &j) == nil {
						doneFile = j.Done
					}
				}
			}
		case "--serve":
			serveOnly = true
			if i+1 < len(os.Args) && !strings.HasPrefix(os.Args[i+1], "--") {
				portFile = os.Args[i+1]
			}
		}
	}
	os.MkdirAll(toolsDir(), 0755)
	sharedPort := filepath.Join(toolsDir(), "port.txt")

	// the panel's engine: reuse one that is already running, so only one works at a time
	if serveOnly {
		if b, err := os.ReadFile(sharedPort); err == nil {
			u := strings.TrimSpace(string(b))
			c := &http.Client{Timeout: 1500 * time.Millisecond}
			if resp, e := c.Post(u+"api/ping", "application/json", nil); e == nil {
				resp.Body.Close()
				if portFile != "" {
					os.WriteFile(portFile, []byte(u), 0644)
				}
				return
			}
		}
	}

	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return
	}
	url := "http://" + ln.Addr().String() + "/"
	go http.Serve(ln, newMux())

	if !serveOnly {
		// the Studio window. It blocks until the window is closed.
		if runWindow(url) {
			if os.Getenv("PPS_WINDOW_TEST") == "1" { // CI: did the page inside the window load and talk to the engine?
				mu.Lock()
				ok := pinged
				mu.Unlock()
				if !ok {
					os.Exit(3)
				}
				os.Exit(0)
			}
			shutdown()
			return
		}
		openBrowserWindow(url) // no WebView2 on this PC: fall back to an app-style browser window
	} else {
		os.WriteFile(sharedPort, []byte(url), 0644)
		if portFile != "" {
			os.WriteFile(portFile, []byte(url), 0644)
		}
	}

	// headless / fallback: quit when nobody has been using the engine for a while
	started := time.Now()
	for {
		time.Sleep(3 * time.Second)
		mu.Lock()
		running := st.State == "running"
		gone := !running && ((pinged && time.Since(lastPing) > 180*time.Second) || (!pinged && time.Since(started) > 120*time.Second))
		mu.Unlock()
		if gone {
			shutdown()
		}
	}
}
