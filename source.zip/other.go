//go:build !windows

package main

import (
	"os"
	"os/exec"
	"path/filepath"
)

func hide(c *exec.Cmd) {}
func toolsDir() string {
	if d := os.Getenv("PPS_HOME"); d != "" {
		return d
	}
	return filepath.Join(os.TempDir(), "pps")
}
func exeName(n string) string       { return n }
func pickFile() string              { return os.Getenv("PPS_PICK") }
func openWindow(u string) *exec.Cmd { println("OPEN", u); return nil }
func openPath(p string, s bool)     {}
