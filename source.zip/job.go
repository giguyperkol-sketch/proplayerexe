package main

// One enhancement job: extract frames -> AI upscale -> filters + encode -> before/after preview.
// The AI and the encoder run at the same time: every finished AI frame goes straight into ffmpeg.

import (
	"context"
	"fmt"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

// Params is what the UI / the After Effects panel sends to /api/start.
type Params struct {
	Path        string `json:"path"`
	Model       string `json:"model"` // a mode key (fast, quality, max, anime) or an older model name
	Scale       int    `json:"scale"`
	ReduceNoise int    `json:"reduceNoise"`
	Sharpen     int    `json:"sharpen"`
	AddNoise    int    `json:"addNoise"`
	RecoverOrig int    `json:"recoverOrig"`
	VideoType   string `json:"videoType"`
	Revert      int    `json:"revert"`
	Recover     int    `json:"recover"`
	Dehalo      int    `json:"dehalo"`
	AntiAlias   int    `json:"antialias"`
	Hair        int    `json:"hair"`
	Ss          string `json:"ss"`
	Dur         string `json:"dur"`
	Done        string `json:"done"`
	Auto        bool   `json:"auto"`
}

var imgExt = map[string]bool{".png": true, ".jpg": true, ".jpeg": true, ".webp": true, ".bmp": true, ".tif": true, ".tiff": true}

const resultSuffix = "_אחרי-טופלייר"

func progress(stage, pct int, text string) {
	setSt(func(s *Status) { s.Stage = stage; s.Pct = pct; s.Text = text })
}

func fail(msg string) {
	logf("FAILED: %s", msg)
	writeDone("ERR|" + msg)
	setSt(func(s *Status) { s.State = "error"; s.Err = msg; s.Text = msg })
}

var doneFile string

func writeDone(t string) {
	if doneFile != "" {
		os.WriteFile(doneFile, []byte(t), 0644)
	}
}

// cleanTimes keeps only valid, plain-decimal start/length values (or none at all).
func cleanTimes(p *Params) {
	if p.Ss == "" && p.Dur == "" {
		return
	}
	sv, ok1 := cleanSecs(p.Ss)
	dv, ok2 := cleanSecs(p.Dur)
	if !ok1 || !ok2 || dv <= 0.02 {
		p.Ss, p.Dur = "", ""
		return
	}
	p.Ss, p.Dur = strconv.FormatFloat(math.Max(0, sv), 'f', 4, 64), strconv.FormatFloat(dv, 'f', 4, 64)
}

// fitBox shrinks w x h (keeping the shape) so it fits in bw x bh; sizes stay even.
func fitBox(w, h, bw, bh int) (int, int) {
	if w <= bw && h <= bh {
		return w / 2 * 2, h / 2 * 2
	}
	r := math.Min(float64(bw)/float64(w), float64(bh)/float64(h))
	return even(float64(w) * r), even(float64(h) * r)
}

func runJob(p Params) {
	ctx, cancel := context.WithCancel(context.Background())
	setCancel(cancel)
	jobStart := time.Now()
	defer func() {
		cancel()
		if r := recover(); r != nil {
			fail(fmt.Sprint("שגיאה פנימית: ", r))
		}
	}()
	cancelled := func() bool {
		if ctx.Err() != nil {
			fail("בוטל")
			return true
		}
		return false
	}

	cleanTimes(&p)
	mode := modeFor(p.Model)
	calibrate(&p)
	logf("=== job %s | mode=%s net=%s | %+v", appVersion, mode.Key, mode.Net, p)

	ff, esr, err := ensureTools(ctx)
	if err != nil {
		if !cancelled() {
			fail(err.Error())
		}
		return
	}
	work := filepath.Join(toolsDir(), "work")
	os.RemoveAll(work)
	fin, fout := filepath.Join(work, "fin"), filepath.Join(work, "fout")
	os.MkdirAll(fin, 0755)
	os.MkdirAll(fout, 0755)
	defer os.RemoveAll(work)

	isImg := imgExt[strings.ToLower(filepath.Ext(p.Path))]
	info := probe(ctx, ff, p.Path)
	if info.W == 0 {
		fail("לא הצלחנו לקרוא את הקובץ הזה. ודא שזה קליפ או תמונה תקינים")
		return
	}
	fps := info.Fps
	if fps <= 0 || fps > 1000 {
		fps = 25
	}
	note := fmt.Sprintf("%dx%d", info.W, info.H)
	if !isImg {
		note += fmt.Sprintf(" · %.0ffps · %.1f שנ'", fps, info.Dur)
		if fps > 60.5 {
			note += fmt.Sprintf(" · הופחת ל-60fps (מ-%.0f)", fps)
			fps = 60
		}
	}

	// sizes: the result is 2x the source (sources above 1080p are first brought to 1080p, so the result stays 4K-class)
	bw, bh := 1920, 1080
	if info.W < info.H {
		bw, bh = bh, bw
	}
	srcW, srcH := fitBox(info.W, info.H, bw, bh)
	if srcW != info.W/2*2 || srcH != info.H/2*2 {
		note += fmt.Sprintf(" · הוקטן ל-%dx%d לפני ההגדלה", srcW, srcH)
	}
	tw, th := srcW*2, srcH*2
	inW, inH := even(float64(tw)*mode.Feed), even(float64(th)*mode.Feed)
	setSt(func(s *Status) { s.Video = !isImg; s.Info = note; s.Mode = mode.Key })

	// 1. frames out of the clip, cleaned up and sized for the AI
	progress(1, 17, "מחלץ פריימים")
	ex := []string{"-hide_banner", "-nostdin", "-y"}
	if p.Ss != "" {
		ex = append(ex, "-ss", p.Ss, "-t", p.Dur)
	}
	ex = append(ex, "-i", p.Path)
	if pre := preFilters(p, info.Fps, info.W, info.H, inW, inH); len(pre) > 0 {
		ex = append(ex, "-vf", strings.Join(pre, ","))
	}
	ex = append(ex, "-fps_mode", "passthrough", "-compression_level", "1", filepath.Join(fin, "%06d.png"))
	est := int(info.Dur * fps)
	if d, e := strconv.ParseFloat(p.Dur, 64); e == nil && d > 0 {
		est = int(d * fps)
	}
	out, e := runTick(ctx, work, ff, ex, func(time.Duration) {
		n := countFiles(fin)
		if est > 0 {
			progress(1, 17+clampInt(5*n/est, 0, 4), fmt.Sprintf("מחלץ פריימים: %d מתוך כ-%d", n, est))
		} else {
			progress(1, 17, fmt.Sprintf("מחלץ פריימים: %d", n))
		}
	})
	if e != nil {
		if !cancelled() {
			fail("חילוץ הפריימים נכשל. " + tail(out))
		}
		return
	}
	total := countFiles(fin)
	logf("extract: %d frames %dx%d -> AI input %dx%d in %.1fs", total, info.W, info.H, inW, inH, time.Since(jobStart).Seconds())
	if total == 0 {
		fail("לא נמצאו פריימים בקובץ")
		return
	}
	setSt(func(s *Status) { s.Frames = total })

	// 2 + 3. AI upscale and encode
	progress(2, 22, "הגדלה בבינה מלאכותית")
	aiStart := time.Now()
	aiDone := make(chan struct{})
	var aiOut string
	var aiErr error
	go func() {
		aiOut, aiErr = run(ctx, filepath.Dir(esr), esr, "-i", fin, "-o", fout, "-n", mode.Net, "-s", strconv.Itoa(mode.Scale),
			"-j", fmt.Sprintf("2:2:%d", mode.Saves), "-f", "jpg", "-m", filepath.Join(filepath.Dir(esr), "models"))
		close(aiDone)
	}()

	pfmt := "yuv420p" // video is filtered in 4:2:0 (half the work; the result is 4:2:0 anyway); stills keep full color
	if isImg {
		pfmt = "yuv444p"
	}
	post := postFilters(p, pfmt)
	ro := float64(p.RecoverOrig) / 100 * 0.12

	outExt := ".mp4"
	if isImg {
		outExt = ".png"
	}
	tmpOut := filepath.Join(work, "out"+outExt)
	x264 := []string{"-c:v", "libx264", "-crf", "12", "-preset", "faster"}
	nvenc := []string{"-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", "14", "-b:v", "0"}
	enc := x264
	if !isImg && nvencOK(ff) {
		enc = nvenc
	}

	// buildArgs: mode "ai" = AI frames (a file for stills, the pipe for video); "plain" = no AI, classic upscale
	buildArgs := func(kind string, enc []string) []string {
		args := []string{"-hide_banner", "-y"}
		var fc string
		ai, orig := 0, 1
		if kind == "ai" {
			blend := ro > 0.03 || ro < -0.01
			if blend {
				args = append(args, "-framerate", fmt.Sprint(fps), "-i", filepath.Join(fin, "%06d.png"))
				ai, orig = 1, 2
			}
			if isImg {
				args = append(args, "-i", filepath.Join(fout, "000001.jpg"))
			} else {
				args = append(args, "-f", "image2pipe", "-framerate", fmt.Sprint(fps), "-c:v", "mjpeg", "-i", "pipe:0")
			}
			aiSc := fmt.Sprintf("[%d:v]scale=%d:%d:flags=lanczos:in_range=full:in_color_matrix=bt601:out_color_matrix=bt709:out_range=tv,format=%s", ai, tw, th, pfmt)
			origSc := fmt.Sprintf("[0:v]scale=%d:%d:flags=bicubic:out_color_matrix=bt709:out_range=tv,format=%s", tw, th, pfmt)
			switch {
			case ro < -0.01: // negative Recover Original Detail: soften with a blurred copy of the original
				fc = fmt.Sprintf("%s,gblur=sigma=3[o];%s[a];[o][a]blend=all_mode=normal:all_opacity=%.2f%s[res]", origSc, aiSc, 1-math.Min(0.5, -ro*3), post)
			case blend:
				fc = fmt.Sprintf("%s[o];%s[a];[o][a]blend=all_mode=normal:all_opacity=%.2f%s[res]", origSc, aiSc, ro, post)
			default:
				fc = aiSc + post + "[res]"
			}
		} else {
			args = append(args, "-framerate", fmt.Sprint(fps), "-i", filepath.Join(fin, "%06d.png"))
			fc = fmt.Sprintf("[0:v]scale=%d:%d:flags=lanczos:out_color_matrix=bt709:out_range=tv,format=%s%s[res]", tw, th, pfmt, post)
		}
		if isImg {
			fc = strings.Replace(fc, "[res]", ",scale=in_range=tv:in_color_matrix=bt709,format=rgb24[res]", 1)
			return append(args, "-filter_complex", fc, "-map", "[res]", "-frames:v", "1", tmpOut)
		}
		if p.Ss != "" {
			args = append(args, "-ss", p.Ss, "-t", p.Dur)
		}
		args = append(args, "-i", p.Path, "-filter_complex", fc, "-map", "[res]", "-map", fmt.Sprintf("%d:a?", orig))
		args = append(args, enc...)
		return append(args, "-pix_fmt", "yuv420p", "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv",
			"-c:a", "aac", "-b:a", "256k", "-shortest", "-movflags", "+faststart", tmpOut)
	}

	useAI := true
	if isImg {
		<-aiDone
		logf("AI (still): %.1fs err=%v %s", time.Since(aiStart).Seconds(), aiErr, tail(aiOut))
		if cancelled() {
			return
		}
		useAI = aiErr == nil && exists(filepath.Join(fout, "000001.jpg"))
	} else {
		useAI = streamEncode(ctx, ff, work, buildArgs("ai", enc), fout, total, aiDone, aiStart)
		<-aiDone
		logf("AI: net=%s x%d in %dx%d -> done in %.1fs err=%v %s", mode.Net, mode.Scale, inW, inH, time.Since(aiStart).Seconds(), aiErr, tail(aiOut))
		if cancelled() {
			return
		}
		if aiErr != nil {
			useAI = false
		}
		if !useAI {
			os.Remove(tmpOut)
		}
	}

	encStart := time.Now()
	if !useAI {
		warn := "ה-AI לא עבד, ולכן נעשתה הגדלה רגילה בלבד. " + tail(aiOut)
		if aiErr == nil {
			warn = "ה-AI לא החזיר את כל הפריימים, ולכן נעשתה הגדלה רגילה בלבד. " + tail(aiOut)
		}
		if r := []rune(warn); len(r) > 240 {
			warn = string(r[:240])
		}
		logf("AI not used: %s", warn)
		setSt(func(s *Status) { s.Info += " · בלי AI"; s.Warn = warn })
	}
	if isImg || !useAI {
		kind := "plain"
		if useAI {
			kind = "ai"
		}
		progress(3, 90, "מאחד ומייצא")
		tick := func(el time.Duration) {
			progress(3, 90+int(el.Seconds()/6)%6, fmt.Sprintf("מאחד ומייצא (%d שניות)", int(el.Seconds())))
		}
		args := buildArgs(kind, enc)
		logf("encoder (%s): %s", kind, strings.Join(args, " "))
		out, e := runTick(ctx, work, ff, args, tick)
		if (e != nil || !exists(tmpOut)) && !isImg && enc[1] == "h264_nvenc" && ctx.Err() == nil {
			logf("nvenc failed, retrying with x264: %s", tail(out))
			os.Remove(tmpOut)
			out, e = runTick(ctx, work, ff, buildArgs(kind, x264), tick)
		}
		if e != nil || !exists(tmpOut) {
			if !cancelled() {
				logf("encode failed: %v | %s", e, out)
				fail("הייצוא נכשל. " + tail(out))
			}
			return
		}
	}
	logf("encode finished %.1fs after the AI; total %.1fs", time.Since(encStart).Seconds(), time.Since(jobStart).Seconds())

	// save next to the source (dropped files go to Videos\ProPlayer Studio)
	base := strings.TrimSuffix(filepath.Base(p.Path), filepath.Ext(p.Path))
	dir := filepath.Dir(p.Path)
	if strings.HasPrefix(p.Path, filepath.Join(toolsDir(), "uploads")) {
		if h, e := os.UserHomeDir(); e == nil {
			dir = filepath.Join(h, "Videos", "ProPlayer Studio")
			os.MkdirAll(dir, 0755)
		}
	}
	final := filepath.Join(dir, base+resultSuffix+outExt)
	for i := 2; exists(final); i++ {
		final = filepath.Join(dir, fmt.Sprintf("%s%s_%d%s", base, resultSuffix, i, outExt))
	}
	if e := moveFile(tmpOut, final); e != nil {
		fail("לא הצלחנו לשמור את התוצאה בתיקייה של המקור: " + e.Error())
		return
	}

	// before / after preview frames (the same part of the clip on both sides)
	progress(4, 96, "מכין תצוגת לפני ואחרי")
	pv := filepath.Join(toolsDir(), "pv")
	os.RemoveAll(pv)
	os.MkdirAll(pv, 0755)
	vf, n := "scale=960:-2", "1"
	if !isImg {
		vf, n = "fps=8,scale=960:-2", "48"
	}
	src := []string{"-hide_banner", "-nostdin", "-y"}
	if p.Ss != "" {
		src = append(src, "-ss", p.Ss, "-t", p.Dur)
	}
	run(ctx, work, ff, append(src, "-i", p.Path, "-vf", vf, "-frames:v", n, "-q:v", "3", filepath.Join(pv, "b_%03d.jpg"))...)
	run(ctx, work, ff, "-hide_banner", "-nostdin", "-y", "-i", final, "-vf", vf, "-frames:v", n, "-q:v", "3", filepath.Join(pv, "a_%03d.jpg"))

	logf("done: %s (%.1fs)", final, time.Since(jobStart).Seconds())
	writeDone("OK|" + final)
	setSt(func(s *Status) {
		s.State = "done"
		s.Out = final
		s.Pct = 100
		s.Stage = 5
		s.Secs = int(time.Since(jobStart).Seconds())
		s.Text = "סיום. נשמר ב: " + dir
	})
}

// streamEncode runs the encoder while the AI works, feeding it each AI frame as soon as it is written.
// It returns true when every frame went through and the file was written.
func streamEncode(ctx context.Context, ff, work string, args []string, fout string, total int, aiDone <-chan struct{}, aiStart time.Time) bool {
	logf("encoder (stream): %s", strings.Join(args, " "))
	c := exec.CommandContext(ctx, ff, args...)
	c.Dir = work
	hide(c)
	tw := &tailWriter{max: 8 << 10}
	c.Stdout, c.Stderr = tw, tw
	stdin, err := c.StdinPipe()
	if err != nil || c.Start() != nil {
		logf("encoder did not start: %v", err)
		return false
	}
	fed := 0
	feedDone := make(chan struct{})
	go func() {
		fed = feedFrames(ctx, stdin, fout, total, aiDone)
		stdin.Close()
		close(feedDone)
	}()
	encFin := make(chan error, 1)
	go func() { <-feedDone; encFin <- c.Wait() }()
	tk := time.NewTicker(700 * time.Millisecond)
	defer tk.Stop()
	for {
		select {
		case e := <-encFin:
			logf("encoder (stream) finished: fed %d/%d err=%v %s", fed, total, e, tail(tw.String()))
			return e == nil && fed == total && exists(filepath.Join(work, "out.mp4"))
		case <-tk.C:
			n := countFiles(fout)
			if n >= total {
				progress(3, 90, "מסיים את הייצוא...")
				continue
			}
			txt := fmt.Sprintf("משפר בבינה מלאכותית · פריים %d מתוך %d", n, total)
			if n >= 3 {
				el := time.Since(aiStart)
				txt += " · נשארו כ-" + fmtDur(time.Duration(float64(el)/float64(n)*float64(total-n)))
			}
			progress(2, 22+int(68*float64(n)/float64(total)), txt)
		}
	}
}
