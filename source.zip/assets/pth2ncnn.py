"""Convert a Real-ESRGAN SRVGGNetCompact .pth into ncnn .param/.bin (same layout as the official realesr-animevideov3 files).
No PyTorch needed: the .pth zip is read with a small custom unpickler."""
import zipfile, pickle, struct, sys, collections
import numpy as np

def load_pth(path):
    z = zipfile.ZipFile(path)
    prefix = z.namelist()[0].split('/')[0]
    dt = {'FloatStorage': np.float32, 'HalfStorage': np.float16}
    class U(pickle.Unpickler):
        def find_class(self, mod, name):
            if mod == 'torch._utils' and name == '_rebuild_tensor_v2':
                def rb(storage, offset, size, stride, *a):
                    arr, = storage
                    n = int(np.prod(size)) if size else 1
                    return np.lib.stride_tricks.as_strided(arr[offset:], shape=size, strides=[s * arr.itemsize for s in stride]).copy() if size else arr[offset:offset+1].copy()
                return rb
            if mod == 'torch' and name.endswith('Storage'):
                return name
            if mod == 'collections' and name == 'OrderedDict':
                return collections.OrderedDict
            return super().find_class(mod, name)
        def persistent_load(self, pid):
            _, typ, key, loc, numel = pid
            raw = z.read(f'{prefix}/data/{key}')
            return (np.frombuffer(raw, dtype=dt[typ]).astype(np.float32),)
    d = U(z.open(f'{prefix}/data.pkl')).load()
    for k in ('params_ema', 'params'):
        if isinstance(d, dict) and k in d:
            return d[k]
    return d

def convs(sd):
    """returns [(weight, bias, prelu_slope or None)] in order, plus the upscale factor"""
    idx = sorted({int(k.split('.')[1]) for k in sd if k.startswith('body.')})
    out, i = [], 0
    while i < len(idx):
        n = idx[i]
        w, b = sd[f'body.{n}.weight'], sd[f'body.{n}.bias']
        slope = None
        if i + 1 < len(idx) and f'body.{idx[i+1]}.weight' in sd and sd[f'body.{idx[i+1]}.weight'].ndim == 1:
            slope = sd[f'body.{idx[i+1]}.weight']; i += 1
        out.append((w, b, slope)); i += 1
    return out

def write_ncnn(layers, scale, param_path, bin_path):
    lines, blob, nid = [], bytearray(), [0]
    def name():
        nid[0] += 1; return str(nid[0])
    cur = 'input.1_splitncnn_1'
    lines.append('Input input.1 0 1 data')
    lines.append('Split splitncnn_input0 1 2 data input.1_splitncnn_0 input.1_splitncnn_1')
    for k, (w, b, slope) in enumerate(layers):
        o = name()
        lines.append(f'Convolution Conv_{k} 1 1 {cur} {o} 0={w.shape[0]} 1={w.shape[2]} 4={w.shape[2]//2} 5=1 6={w.size}')
        blob += struct.pack('<I', 0x01306B47) + w.astype(np.float16).tobytes()
        blob += b.astype(np.float32).tobytes()
        cur = o
        if slope is not None:
            o = name()
            lines.append(f'PReLU PRelu_{k} 1 1 {cur} {o} 0={slope.size}')
            blob += slope.astype(np.float32).tobytes()
            cur = o
    o = name(); lines.append(f'PixelShuffle DepthToSpace 1 1 {cur} {o} 0={scale}'); cur = o
    u = name(); lines.append(f'Interp Resize 1 1 input.1_splitncnn_0 {u} 0=1 1={scale:.6e} 2={scale:.6e}')
    lines.append(f'BinaryOp Add 2 1 {cur} {u} output')
    blobs = 0
    for l in lines:
        blobs += int(l.split()[3])
    with open(param_path, 'w') as f:
        f.write('7767517\n%d %d\n' % (len(lines), blobs) + '\n'.join(lines) + '\n')
    open(bin_path, 'wb').write(bytes(blob))

if __name__ == '__main__':
    # usage: pth2ncnn.py out_prefix model.pth [model2.pth blend]
    out = sys.argv[1]
    sd = load_pth(sys.argv[2])
    if len(sys.argv) > 4:  # DNI: weight interpolation between two models (Real-ESRGAN "denoise strength")
        sd2, a = load_pth(sys.argv[3]), float(sys.argv[4])
        sd = {k: a * sd[k] + (1 - a) * sd2[k] for k in sd}
    L = convs(sd)
    scale = int(round((L[-1][0].shape[0] / 3) ** 0.5))
    write_ncnn(L, scale, out + '.param', out + '.bin')
    print(out, 'convs', len(L), 'scale', scale)
