package main

// The quality modes and the AI networks behind them.
//
// realesr-general-x4v3 is the official Real-ESRGAN model for real-world video (people, sport,
// phone footage). It ships inside the EXE (models/), converted to ncnn with assets/pth2ncnn.py
// from the official weights, blended 50/50 with the "wdn" variant (Real-ESRGAN's default
// denoise strength 0.5). The other networks come with the Real-ESRGAN download.

import (
	"bytes"
	"embed"
	"os"
	"path/filepath"
)

//go:embed models/*
var bundledModels embed.FS

type aiMode struct {
	Key   string  // what the UI and the After Effects panel send
	Net   string  // network name for realesrgan-ncnn-vulkan
	Scale int     // native factor of the network
	Feed  float64 // input size as a share of the final size; Feed*Scale > 1 means supersampling (sharper, slower)
	Saves int     // image writer threads (big outputs need more)
}

var modes = map[string]aiMode{
	// final = 2x the source. fast: half-size input, x4 -> exactly the final size.
	"fast": {Key: "fast", Net: "realesr-general-x4v3", Scale: 4, Feed: 0.25, Saves: 2},
	// high quality: 3/4-size input, x4 -> 1.5x the final size, then a clean downscale (supersampling).
	"quality": {Key: "quality", Net: "realesr-general-x4v3", Scale: 4, Feed: 0.375, Saves: 4},
	// maximum: the heavy RRDB network, supersampled the same way. Best detail, slowest.
	"max": {Key: "max", Net: "realesrgan-x4plus", Scale: 4, Feed: 0.375, Saves: 4},
	// anime / cartoons / games: the anime video network at its native x2.
	"anime": {Key: "anime", Net: "realesr-animevideov3", Scale: 2, Feed: 0.5, Saves: 2},
}

// modeFor accepts the new keys and the model names older panels send.
func modeFor(key string) aiMode {
	if m, ok := modes[key]; ok {
		return m
	}
	switch key {
	case "realesr-animevideov3": // older panels: "fast"
		return modes["fast"]
	case "realesrgan-x4plus-anime":
		return modes["anime"]
	}
	return modes["quality"]
}

// installModels copies the bundled networks next to the Real-ESRGAN ones (only when missing or changed).
func installModels(dir string) error {
	os.MkdirAll(dir, 0755)
	ents, err := bundledModels.ReadDir("models")
	if err != nil {
		return err
	}
	for _, e := range ents {
		b, _ := bundledModels.ReadFile("models/" + e.Name())
		dst := filepath.Join(dir, e.Name())
		if old, err := os.ReadFile(dst); err == nil && bytes.Equal(old, b) {
			continue
		}
		tmp := dst + ".tmp"
		if err := os.WriteFile(tmp, b, 0644); err != nil {
			return err
		}
		if err := os.Rename(tmp, dst); err != nil {
			os.Remove(tmp)
			return err
		}
	}
	return nil
}
