package main

// First run: download ffmpeg and the Real-ESRGAN engine once, then install the bundled models.

import (
	"archive/zip"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const (
	ffURL  = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
	esrURL = "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-windows.zip"
)

// download saves url to dst (through a temp file, with one retry), reporting progress between p0 and p1.
func download(ctx context.Context, url, dst string, p0, p1 int, label string) error {
	var err error
	for attempt := 0; attempt < 2; attempt++ {
		if err = downloadOnce(ctx, url, dst, p0, p1, label); err == nil || ctx.Err() != nil {
			return err
		}
		logf("download %s failed (attempt %d): %v", url, attempt+1, err)
		time.Sleep(2 * time.Second)
	}
	return err
}

func downloadOnce(ctx context.Context, url, dst string, p0, p1 int, label string) error {
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", "ProPlayerStudio/"+appVersion)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return fmt.Errorf("http %d", resp.StatusCode)
	}
	tmp := dst + ".part"
	f, err := os.Create(tmp)
	if err != nil {
		return err
	}
	buf := make([]byte, 512<<10)
	var got int64
	last := time.Now()
	for {
		n, e := resp.Body.Read(buf)
		if n > 0 {
			if _, we := f.Write(buf[:n]); we != nil {
				f.Close()
				os.Remove(tmp)
				return we
			}
			got += int64(n)
			if time.Since(last) > 300*time.Millisecond && resp.ContentLength > 0 {
				last = time.Now()
				progress(0, p0+int(int64(p1-p0)*got/resp.ContentLength), fmt.Sprintf("%s · %d / %d MB", label, got>>20, resp.ContentLength>>20))
			}
		}
		if e == io.EOF {
			break
		}
		if e != nil {
			f.Close()
			os.Remove(tmp)
			return e
		}
	}
	if err := f.Close(); err != nil {
		os.Remove(tmp)
		return err
	}
	if resp.ContentLength > 0 && got != resp.ContentLength {
		os.Remove(tmp)
		return fmt.Errorf("incomplete download (%d of %d bytes)", got, resp.ContentLength)
	}
	return os.Rename(tmp, dst)
}

// unzip extracts src into dst. With only set, just the file with that name is extracted (flattened).
func unzip(src, dst, only string) error {
	zr, err := zip.OpenReader(src)
	if err != nil {
		return err
	}
	defer zr.Close()
	for _, f := range zr.File {
		if f.FileInfo().IsDir() {
			continue
		}
		name := filepath.ToSlash(f.Name)
		if strings.Contains(name, "..") {
			continue
		}
		if only != "" {
			if !strings.HasSuffix(strings.ToLower(name), "/"+only) && strings.ToLower(name) != only {
				continue
			}
			name = only
		}
		p := filepath.Join(dst, filepath.FromSlash(name))
		os.MkdirAll(filepath.Dir(p), 0755)
		rc, err := f.Open()
		if err != nil {
			return err
		}
		w, err := os.Create(p)
		if err != nil {
			rc.Close()
			return err
		}
		_, cerr := io.Copy(w, rc)
		w.Close()
		rc.Close()
		if cerr != nil {
			return cerr
		}
	}
	return nil
}

// ensureTools returns the paths of ffmpeg and the AI engine, downloading them the first time.
func ensureTools(ctx context.Context) (ff, esr string, err error) {
	td := toolsDir()
	ff = os.Getenv("PPS_FFMPEG")
	if ff == "" {
		ff = filepath.Join(td, "ff", exeName("ffmpeg"))
	}
	esr = os.Getenv("PPS_ESRGAN")
	if esr == "" {
		esr = filepath.Join(td, "esr", exeName("realesrgan-ncnn-vulkan"))
	}
	if !exists(ff) {
		os.MkdirAll(filepath.Join(td, "ff"), 0755)
		z := filepath.Join(td, "ff.zip")
		if e := download(ctx, ffURL, z, 1, 12, "מוריד את כלי הווידאו (פעם אחת בלבד)"); e != nil {
			return "", "", errors.New("לא הצלחנו להוריד את כלי הווידאו. בדוק את החיבור לאינטרנט ונסה שוב")
		}
		progress(0, 12, "פותח את כלי הווידאו...")
		if e := unzip(z, filepath.Join(td, "ff"), exeName("ffmpeg")); e != nil || !exists(ff) {
			return "", "", errors.New("פתיחת כלי הווידאו נכשלה")
		}
		os.Remove(z)
	}
	if !exists(esr) {
		os.MkdirAll(filepath.Join(td, "esr"), 0755)
		z := filepath.Join(td, "esr.zip")
		if e := download(ctx, esrURL, z, 12, 16, "מוריד את מנוע ה-AI (פעם אחת בלבד)"); e != nil {
			return "", "", errors.New("לא הצלחנו להוריד את מנוע ה-AI. בדוק את החיבור לאינטרנט ונסה שוב")
		}
		if e := unzip(z, filepath.Join(td, "esr"), ""); e != nil || !exists(esr) {
			return "", "", errors.New("פתיחת מנוע ה-AI נכשלה")
		}
		os.Remove(z)
	}
	if e := installModels(filepath.Join(filepath.Dir(esr), "models")); e != nil {
		logf("installing bundled models failed: %v", e)
	}
	return ff, esr, nil
}
