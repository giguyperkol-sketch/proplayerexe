package main

import (
	"archive/zip"
	"context"
	"errors"
	"fmt"
	"io"
	"math"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Params struct {
	Path        string `json:"path"`
	Model       string `json:"model"`
	Scale       int    `json:"scale"` // 2 or 4
	ReduceNoise int    `json:"reduceNoise"`
	Sharpen     int    `json:"sharpen"`
	AddNoise    int    `json:"addNoise"`
	RecoverOrig int    `json:"recoverOrig"`
	VideoType   string `json:"videoType"`
	Revert      int    `json:"revert"`
	Recover     int    `json:"recover"`
	Dehalo      int    `json:"dehalo"`
	AntiAlias   int    `json:"antialias"`
	Hair        int    `json:"hair"`
	Ss          string `json:"ss"`
	Dur         string `json:"dur"`
	Done        string `json:"done"`
	Auto        bool   `json:"auto"`
}

const ffURL = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
const esrURL = "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-windows.zip"

var imgExt = map[string]bool{".png": true, ".jpg": true, ".jpeg": true, ".webp": true, ".bmp": true}

func progress(stage, pct int, text string) {
	setSt(func(s *Status) { s.Stage = stage; s.Pct = pct; s.Text = text })
}

func fail(msg string) {
	writeDone("ERR|" + msg)
	setSt(func(s *Status) { s.State = "error"; s.Err = msg; s.Text = msg })
}

var logMu sync.Mutex

// logf appends a line to studio-log.txt (stage timings, full commands, tool errors) so any failure can be diagnosed
func logf(format string, a ...interface{}) {
	logMu.Lock()
	defer logMu.Unlock()
	f, err := os.OpenFile(filepath.Join(toolsDir(), "studio-log.txt"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	fmt.Fprintf(f, "%s  %s\n", time.Now().Format("15:04:05"), fmt.Sprintf(format, a...))
}

func exists(p string) bool { _, e := os.Stat(p); return e == nil }

func download(ctx context.Context, url, dst string, stage, p0, p1 int, label string) error {
	req, _ := http.NewRequestWithContext(ctx, "GET", url, nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return fmt.Errorf("http %d", resp.StatusCode)
	}
	f, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer f.Close()
	buf := make([]byte, 256*1024)
	var got int64
	last := time.Now()
	for {
		n, e := resp.Body.Read(buf)
		if n > 0 {
			f.Write(buf[:n])
			got += int64(n)
			if time.Since(last) > 300*time.Millisecond && resp.ContentLength > 0 {
				last = time.Now()
				progress(stage, p0+int(int64(p1-p0)*got/resp.ContentLength), fmt.Sprintf("%s %d MB", label, got>>20))
			}
		}
		if e == io.EOF {
			return nil
		}
		if e != nil {
			return e
		}
	}
}

func unzip(src, dst string, only string) error {
	zr, err := zip.OpenReader(src)
	if err != nil {
		return err
	}
	defer zr.Close()
	for _, f := range zr.File {
		if f.FileInfo().IsDir() {
			continue
		}
		name := filepath.ToSlash(f.Name)
		if only != "" {
			if !strings.HasSuffix(strings.ToLower(name), "/"+only) && strings.ToLower(name) != only {
				continue
			}
			name = only
		}
		p := filepath.Join(dst, filepath.FromSlash(name))
		os.MkdirAll(filepath.Dir(p), 0755)
		rc, err := f.Open()
		if err != nil {
			return err
		}
		w, err := os.Create(p)
		if err != nil {
			rc.Close()
			return err
		}
		io.Copy(w, rc)
		w.Close()
		rc.Close()
	}
	return nil
}

func ensureTools(ctx context.Context) (ff, esr string, err error) {
	td := toolsDir()
	ff = os.Getenv("PPS_FFMPEG")
	if ff == "" {
		ff = filepath.Join(td, "ff", exeName("ffmpeg"))
	}
	esr = os.Getenv("PPS_ESRGAN")
	if esr == "" {
		esr = filepath.Join(td, "esr", exeName("realesrgan-ncnn-vulkan"))
	}
	if !exists(ff) {
		os.MkdirAll(filepath.Join(td, "ff"), 0755)
		z := filepath.Join(td, "ff.zip")
		if e := download(ctx, ffURL, z, 0, 1, 12, "מוריד כלי וידאו (פעם אחת)"); e != nil {
			return "", "", errors.New("לא הצלחנו להוריד את כלי הוידאו. בדוק אינטרנט")
		}
		if e := unzip(z, filepath.Join(td, "ff"), exeName("ffmpeg")); e != nil || !exists(ff) {
			return "", "", errors.New("פתיחת כלי הוידאו נכשלה")
		}
		os.Remove(z)
	}
	if !exists(esr) {
		os.MkdirAll(filepath.Join(td, "esr"), 0755)
		z := filepath.Join(td, "esr.zip")
		if e := download(ctx, esrURL, z, 0, 12, 16, "מוריד את מנוע ה-AI (פעם אחת)"); e != nil {
			return "", "", errors.New("לא הצלחנו להוריד את מנוע ה-AI. בדוק אינטרנט")
		}
		if e := unzip(z, filepath.Join(td, "esr"), ""); e != nil || !exists(esr) {
			return "", "", errors.New("פתיחת מנוע ה-AI נכשלה")
		}
		os.Remove(z)
	}
	return ff, esr, nil
}

type probeInfo struct {
	W, H int
	Fps  float64
	Dur  float64
}

var reSize = regexp.MustCompile(`Video:.*?[ ,](\d{2,5})x(\d{2,5})`)
var reFps = regexp.MustCompile(`([\d.]+) fps`)
var reDur = regexp.MustCompile(`Duration: (\d+):(\d+):([\d.]+)`)

func probe(ctx context.Context, ff, file string) probeInfo {
	c := exec.CommandContext(ctx, ff, "-hide_banner", "-i", file)
	hide(c)
	o, _ := c.CombinedOutput()
	s := string(o)
	var p probeInfo
	if m := reSize.FindStringSubmatch(s); m != nil {
		p.W, _ = strconv.Atoi(m[1])
		p.H, _ = strconv.Atoi(m[2])
	}
	if m := reFps.FindStringSubmatch(s); m != nil {
		p.Fps, _ = strconv.ParseFloat(m[1], 64)
	}
	if m := reDur.FindStringSubmatch(s); m != nil {
		h, _ := strconv.Atoi(m[1])
		mi, _ := strconv.Atoi(m[2])
		se, _ := strconv.ParseFloat(m[3], 64)
		p.Dur = float64(h*3600+mi*60) + se
	}
	return p
}

func run(ctx context.Context, dir, name string, args ...string) (string, error) {
	c := exec.CommandContext(ctx, name, args...)
	c.Dir = dir
	hide(c)
	o, err := c.CombinedOutput()
	return string(o), err
}

func runTick(ctx context.Context, dir, name string, args []string, f func(el time.Duration)) (string, error) {
	type res struct {
		o string
		e error
	}
	ch := make(chan res, 1)
	go func() { o, e := run(ctx, dir, name, args...); ch <- res{o, e} }()
	t0 := time.Now()
	tk := time.NewTicker(700 * time.Millisecond)
	defer tk.Stop()
	for {
		select {
		case r := <-ch:
			return r.o, r.e
		case <-tk.C:
			f(time.Since(t0))
		}
	}
}

func countFiles(dir string) int {
	es, _ := os.ReadDir(dir)
	return len(es)
}

func runJob(p Params) {
	ctx, cancel := context.WithCancel(context.Background())
	cancelFn = func() { cancel() }
	defer func() {
		cancel()
		if r := recover(); r != nil {
			fail(fmt.Sprint("שגיאה: ", r))
		}
	}()
	logf("=== job: %+v", p)
	jobStart := time.Now()
	ff, esr, err := ensureTools(ctx)
	if err != nil {
		if ctx.Err() != nil {
			fail("בוטל")
		} else {
			fail(err.Error())
		}
		return
	}
	// time values from the panel: always plain decimals, and never a zero / negative length
	if p.Ss != "" || p.Dur != "" {
		sv, ok1 := cleanSecs(p.Ss)
		dv, ok2 := cleanSecs(p.Dur)
		if ok1 && ok2 && dv > 0.02 {
			if sv < 0 {
				sv = 0
			}
			p.Ss, p.Dur = strconv.FormatFloat(sv, 'f', 4, 64), strconv.FormatFloat(dv, 'f', 4, 64)
		} else {
			p.Ss, p.Dur = "", ""
		}
	}
	p.Scale = 2 // plain x2 upscale
	calibrate(&p)
	if p.Model == "" {
		p.Model = "realesrgan-x4plus"
	}
	work := filepath.Join(toolsDir(), "work")
	os.RemoveAll(work)
	fin, fout := filepath.Join(work, "fin"), filepath.Join(work, "fout")
	os.MkdirAll(fin, 0755)
	os.MkdirAll(fout, 0755)
	defer os.RemoveAll(work)

	ext := strings.ToLower(filepath.Ext(p.Path))
	isImg := imgExt[ext]
	info := probe(ctx, ff, p.Path)
	if info.W == 0 {
		fail("לא הצלחנו לקרוא את הקובץ הזה")
		return
	}
	fps := info.Fps
	if fps <= 0 || fps > 240 {
		fps = 25
	}
	setSt(func(s *Status) {
		s.Video = !isImg
		s.Info = fmt.Sprintf("%dx%d", info.W, info.H)
		if !isImg {
			s.Info += fmt.Sprintf(" · %.0ffps · %.1f שנ'", fps, info.Dur)
		}
	})
	progress(1, 17, "מחלץ פריימים")
	var pre []string
	if fps > 60.5 {
		pre = append(pre, "fps=60")
		setSt(func(s *Status) { s.Info += fmt.Sprintf(" · הופחת ל-60fps (מ-%.0f)", fps) })
		fps = 60
	}
	if strings.HasPrefix(p.VideoType, "Interlaced") {
		if p.VideoType == "Interlaced" {
			pre = append(pre, "yadif=mode=send_frame:parity=auto:deint=all")
		} else {
			pre = append(pre, "yadif=mode=send_frame:parity=auto:deint=interlaced")
		}
	}
	if p.Revert > 0 {
		rv := float64(p.Revert) / 100
		a := 0.098 + rv*0.12
		f := "weak"
		if p.Revert > 40 {
			f = "strong"
		}
		pre = append(pre, fmt.Sprintf("deblock=filter=%s:block=8:alpha=%.3f:beta=%.3f:gamma=%.3f:delta=%.3f", f, a, a, a*0.6, a*0.6))
	}
	if p.Revert < 0 {
		// opposite of Revert Compression: blocky, compressed look
		f := 1 + float64(-p.Revert)/100
		pre = append(pre, fmt.Sprintf("scale=%d:%d:flags=area,scale=%d:%d:flags=neighbor", int(float64(info.W)/f)/2*2+2, int(float64(info.H)/f)/2*2+2, info.W/2*2, info.H/2*2))
	}
	if p.Dehalo < 0 {
		// opposite of Dehalo: stronger edge halos
		pre = append(pre, fmt.Sprintf("unsharp=7:7:%.2f:7:7:0", math.Min(5, float64(-p.Dehalo)/100*1.5)))
	}
	if p.AntiAlias < 0 {
		pre = append(pre, fmt.Sprintf("unsharp=3:3:%.2f:3:3:0", math.Min(5, float64(-p.AntiAlias)/100*2)))
	}
	if p.Dehalo > 0 {
		d := float64(p.Dehalo) / 100
		pre = append(pre, fmt.Sprintf("bilateral=sigmaS=%.2f:sigmaR=%.2f", 0.6+d*0.9, 0.05+d*0.08))
	}
	if p.AntiAlias > 0 {
		pre = append(pre, fmt.Sprintf("gblur=sigma=%.2f", 0.1+float64(p.AntiAlias)/100*0.5))
	}
	// keep the final result within 2K (2560x1440): shrink big sources before the AI upscale
	bw, bh := 1920, 1080 // plain x2 of the source (1080p -> 4K); only 8K-class sources get shrunk first
	if info.W < info.H {
		bw, bh = bh, bw
	}
	srcW, srcH := info.W, info.H
	if info.W > bw || info.H > bh {
		ra := float64(bw) / float64(info.W)
		if rb := float64(bh) / float64(info.H); rb < ra {
			ra = rb
		}
		srcW, srcH = int(float64(info.W)*ra)/2*2, int(float64(info.H)*ra)/2*2
		pre = append(pre, fmt.Sprintf("scale=%d:%d:flags=lanczos", srcW, srcH))
		setSt(func(s *Status) { s.Info += fmt.Sprintf(" · הוקטן ל-%dx%d לפני ההגדלה", srcW, srcH) })
	}
	// x4 models: feed them half-size frames so their x4 output is exactly the x2 result (never 8K)
	if strings.Contains(p.Model, "x4plus") {
		pre = append(pre, fmt.Sprintf("scale=%d:%d:flags=lanczos", srcW/4*2, srcH/4*2))
	}
	exArgs := []string{"-hide_banner", "-nostdin", "-y"}
	if p.Ss != "" && p.Dur != "" {
		exArgs = append(exArgs, "-ss", p.Ss, "-t", p.Dur)
	}
	exArgs = append(exArgs, "-i", p.Path)
	if len(pre) > 0 {
		exArgs = append(exArgs, "-vf", strings.Join(pre, ","))
	}
	exArgs = append(exArgs, "-fps_mode", "passthrough", "-compression_level", "1", filepath.Join(fin, "%06d.png"))
	est := int(info.Dur * fps)
	if out, e := runTick(ctx, work, ff, exArgs, func(el time.Duration) {
		n := countFiles(fin)
		pc := 17
		txt := fmt.Sprintf("מחלץ פריימים: %d", n)
		if est > 0 {
			pc = 17 + 5*n/est
			if pc > 21 {
				pc = 21
			}
			txt = fmt.Sprintf("מחלץ פריימים: %d מתוך כ-%d (קליפ גדול לוקח זמן)", n, est)
		}
		progress(1, pc, txt)
	}); e != nil {
		if ctx.Err() != nil {
			fail("בוטל")
		} else {
			fail("חילוץ הפריימים נכשל. " + tail(out))
		}
		return
	}
	total := countFiles(fin)
	logf("extract: %d frames in %.1fs", total, time.Since(jobStart).Seconds())
	if total == 0 {
		fail("לא נמצאו פריימים בקובץ")
		return
	}
	setSt(func(s *Status) { s.Frames = total })
	tw, th := srcW*p.Scale, srcH*p.Scale

	// x4plus models only support x4 (other values misplace the tiles); the result is resized to the requested size afterwards
	esrScale := p.Scale
	if strings.Contains(p.Model, "x4plus") {
		esrScale = 4
	}
	// ---- AI upscale and the final encode run at the same time (the encoder takes each AI frame as soon as it is written) ----
	progress(2, 22, "הגדלה בבינה מלאכותית")
	aiStart := time.Now()
	aiDone := make(chan struct{})
	var aiOut string
	var aiErr error
	go func() {
		// -t 0 = automatic tile size; 2:2:2 = load / process / save threads
		aiOut, aiErr = run(ctx, filepath.Dir(esr), esr, "-i", fin, "-o", fout, "-n", p.Model, "-s", strconv.Itoa(esrScale), "-j", "2:2:2", "-f", "jpg", "-m", filepath.Join(filepath.Dir(esr), "models"))
		close(aiDone)
	}()

	ro := float64(p.RecoverOrig) / 100 * 0.12
	pfmt := "yuv420p" // video is filtered in 4:2:0 (half the work, the result is 4:2:0 anyway); stills keep full chroma
	if isImg {
		pfmt = "yuv444p"
	}
	var pf []string
	if p.ReduceNoise < 0 {
		pf = append(pf, fmt.Sprintf("noise=alls=%d", int(math.Min(60, float64(-p.ReduceNoise)*0.3))))
	}
	if p.AddNoise < 0 {
		an := float64(-p.AddNoise) / 100
		pf = append(pf, fmt.Sprintf("hqdn3d=%.2f:%.2f:%.2f:%.2f", an*8, an*6, an*12, an*9))
	}
	if p.ReduceNoise > 0 {
		rn := float64(p.ReduceNoise) / 100
		pf = append(pf, fmt.Sprintf("hqdn3d=%.2f:%.2f:%.2f:%.2f", rn*1.8, rn*1.4, rn*3, rn*2.4))
	}
	if p.Hair < 0 {
		// opposite of Hair Smoothing: bring out texture in dark areas
		h := math.Min(1, float64(-p.Hair)/100)
		pf = append(pf, fmt.Sprintf("format=yuv420p,split=3[hb][hm][hs];[hs]unsharp=7:7:%.2f:7:7:0[hmed];[hm]scale=iw/4:ih/4,format=gray,lut=y='clip((210-val)*3,0,255)*%.2f',gblur=sigma=2,scale=iw*4:ih*4,format=yuv420p[hmask];[hb][hmed][hmask]maskedmerge=planes=1,format=%s", 1+h*2.5, h, pfmt))
	}
	if p.Hair > 0 {
		h := math.Min(1, float64(p.Hair)/100)
		// smooth only dark, textured areas (hair): median at half size (4x cheaper), gated by a soft darkness mask
		rad := int(1 + h*3)
		pf = append(pf, fmt.Sprintf("format=yuv420p,split=3[hb][hm][hs];[hs]scale=iw/2:ih/2:flags=bilinear,median=radius=%d,scale=iw*2:ih*2:flags=bilinear[hmed];[hm]scale=iw/4:ih/4,format=gray,lut=y='clip((210-val)*3,0,255)*%.2f',gblur=sigma=2,scale=iw*4:ih*4,format=yuv420p[hmask];[hb][hmed][hmask]maskedmerge=planes=1,format=%s", rad, h, pfmt))
	}
	// two sharpening passes only (fine + coarse); amounts combine Sharpen, Recover Details and Anti-alias
	{
		s, r, aa := float64(p.Sharpen)/100, float64(p.Recover)/100, float64(p.AntiAlias)/100
		if fine := math.Max(-2, math.Min(5, s*3.4+r*1.0+math.Max(0, aa)*2.0)); math.Abs(fine) > 0.01 {
			pf = append(pf, fmt.Sprintf("unsharp=5:5:%.2f:5:5:0", fine))
		}
		if coarse := math.Max(-2, math.Min(5, r*2.4)); math.Abs(coarse) > 0.01 {
			pf = append(pf, fmt.Sprintf("unsharp=11:11:%.2f:11:11:0", coarse))
		}
		// halo-free contrast adaptive sharpening on top: keeps the picture crisp
		if c := math.Min(1, s*0.6+r*0.5); c > 0.02 {
			pf = append(pf, fmt.Sprintf("cas=%.2f", c))
		}
	}
	if p.AddNoise > 0 {
		fl := ""
		if p.AddNoise > 8 {
			fl = ":allf=t" // temporal grain is 10x slower, only worth it when the grain is visible
		}
		pf = append(pf, fmt.Sprintf("noise=alls=%d%s", int(math.Min(100, float64(p.AddNoise))), fl))
	}
	post := ""
	if len(pf) > 0 {
		post = ",format=" + pfmt + "," + strings.Join(pf, ",")
	}
	base := strings.TrimSuffix(filepath.Base(p.Path), filepath.Ext(p.Path))
	dir := filepath.Dir(p.Path)
	if strings.HasPrefix(p.Path, filepath.Join(toolsDir(), "uploads")) {
		if h, e := os.UserHomeDir(); e == nil {
			dir = filepath.Join(h, "Videos", "ProPlayer Studio")
			os.MkdirAll(dir, 0755)
		}
	}
	outExt := ".mp4"
	if isImg {
		outExt = ".png"
	}
	tmpOut := filepath.Join(work, "out"+outExt)
	toRGB := ",scale=in_range=tv:in_color_matrix=bt709,format=rgb24" // stills go back to RGB with the same matrix we used going in
	// buildArgs: mode "ai" = AI frames come from files (stills) or from the pipe (video); mode "plain" = no AI, classic upscale
	buildArgs := func(mode string, enc []string) []string {
		args := []string{"-hide_banner", "-y"}
		var fc string
		ai, orig := 0, 1
		if mode == "ai" {
			useBlend := math.Abs(ro) > 0.03 && ro > 0 || ro < -0.01
			png := ""
			if useBlend {
				args = append(args, "-framerate", fmt.Sprint(fps), "-i", filepath.Join(fin, "%06d.png"))
				png = "[0:v]"
				ai, orig = 1, 2
			}
			if isImg {
				args = append(args, "-i", filepath.Join(fout, "000001.jpg"))
			} else {
				args = append(args, "-f", "image2pipe", "-framerate", fmt.Sprint(fps), "-c:v", "mjpeg", "-i", "pipe:0")
			}
			aiSc := fmt.Sprintf("[%d:v]scale=%d:%d:flags=lanczos:in_range=full:in_color_matrix=bt601:out_color_matrix=bt709:out_range=tv,format=%s", ai, tw, th, pfmt)
			switch {
			case ro < -0.01:
				fc = fmt.Sprintf("%sscale=%d:%d:flags=bicubic:out_color_matrix=bt709:out_range=tv,format=%s,gblur=sigma=3[o];%s[a];[o][a]blend=all_mode=normal:all_opacity=%.2f%s[res]", png, tw, th, pfmt, aiSc, 1-math.Min(0.5, -ro*3), post)
			case useBlend:
				fc = fmt.Sprintf("%sscale=%d:%d:flags=bicubic:out_color_matrix=bt709:out_range=tv,format=%s[o];%s[a];[o][a]blend=all_mode=normal:all_opacity=%.2f%s[res]", png, tw, th, pfmt, aiSc, ro, post)
			default:
				fc = aiSc + post + "[res]"
			}
		} else {
			args = append(args, "-framerate", fmt.Sprint(fps), "-i", filepath.Join(fin, "%06d.png"))
			fc = fmt.Sprintf("[0:v]scale=%d:%d:flags=lanczos:out_color_matrix=bt709:out_range=tv,format=%s%s[res]", tw, th, pfmt, post)
			orig = 1
		}
		if isImg {
			fc = strings.Replace(fc, "[res]", toRGB+"[res]", 1)
			return append(args, "-filter_complex", fc, "-map", "[res]", "-frames:v", "1", tmpOut)
		}
		if p.Ss != "" && p.Dur != "" {
			args = append(args, "-ss", p.Ss, "-t", p.Dur)
		}
		args = append(args, "-i", p.Path, "-filter_complex", fc, "-map", "[res]", "-map", fmt.Sprintf("%d:a?", orig))
		args = append(args, enc...)
		args = append(args, "-pix_fmt", "yuv420p", "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv", "-c:a", "aac", "-b:a", "256k", "-shortest", tmpOut)
		return args
	}
	x264 := []string{"-c:v", "libx264", "-crf", "12", "-preset", "faster"}
	nv := []string{"-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", "14", "-b:v", "0"}
	enc := x264
	if !isImg && nvencOK(ff) {
		enc = nv
	}

	useAI := true
	aiWarn := ""
	var encOut string
	var encErr error
	if isImg {
		<-aiDone
		logf("AI (still): %.1fs err=%v out=%s", time.Since(aiStart).Seconds(), aiErr, tail(aiOut))
		if ctx.Err() != nil {
			fail("בוטל")
			return
		}
		if aiErr != nil || !exists(filepath.Join(fout, "000001.jpg")) {
			useAI = false
		}
	} else {
		args := buildArgs("ai", enc)
		logf("encoder(stream): %s", strings.Join(args, " "))
		c := exec.CommandContext(ctx, ff, args...)
		c.Dir = work
		hide(c)
		tw2 := &tailWriter{max: 6000}
		c.Stdout, c.Stderr = tw2, tw2
		stdin, perr := c.StdinPipe()
		if perr != nil || c.Start() != nil {
			useAI = false
		} else {
			var fed int
			feedDone := make(chan struct{})
			go func() {
				fed = feedFrames(ctx, stdin, fout, total, aiDone)
				stdin.Close()
				close(feedDone)
			}()
			encFin := make(chan error, 1)
			go func() { <-feedDone; encFin <- c.Wait() }()
			tk := time.NewTicker(700 * time.Millisecond)
		loop:
			for {
				select {
				case encErr = <-encFin:
					break loop
				case <-tk.C:
					n := countFiles(fout)
					txt := fmt.Sprintf("הגדלה בבינה מלאכותית, פריים %d מתוך %d", n, total)
					if n >= 3 && n < total {
						el := time.Since(aiStart)
						rem := time.Duration(float64(el) / float64(n) * float64(total-n))
						txt += fmt.Sprintf(" · נשארו כ-%s", fmtDur(rem))
					}
					if n >= total {
						txt = fmt.Sprintf("מסיים ייצוא, פריים %d מתוך %d", fed, total)
					}
					progress(2, 22+int(68*float64(n)/float64(total)), txt)
				}
			}
			tk.Stop()
			<-aiDone
			encOut = tw2.String()
			logf("AI: model=%s scale=%d done in %.1fs err=%v out=%s", p.Model, esrScale, time.Since(aiStart).Seconds(), aiErr, tail(aiOut))
			logf("encode(stream) finished: fed=%d/%d err=%v %s", fed, total, encErr, tail(encOut))
			if ctx.Err() != nil {
				fail("בוטל")
				return
			}
			if aiErr != nil || fed < total || encErr != nil || !exists(tmpOut) {
				useAI = false
				os.Remove(tmpOut)
			}
		}
	}
	progress(3, 90, "מאחד ומייצא")
	encStart := time.Now()
	if !useAI {
		// no usable GPU / the AI failed: classic upscale so the job still finishes
		aiWarn = "ה-AI לא עבד ולכן נעשתה הגדלה רגילה בלבד. " + tail(aiOut)
		if aiErr == nil {
			aiWarn = "ה-AI לא החזיר את כל הפריימים ולכן נעשתה הגדלה רגילה בלבד. " + tail(aiOut)
		}
		if len(aiWarn) > 260 {
			aiWarn = aiWarn[:260]
		}
		setSt(func(s *Status) { s.Info += " · בלי AI"; s.Warn = aiWarn })
		if aiErr != nil {
			logf("AI failed: %v | %s", aiErr, tail(aiOut))
		}
	}
	if isImg || !useAI {
		mode := "plain"
		if isImg && useAI {
			mode = "ai"
		}
		args := buildArgs(mode, enc)
		logf("encoder(files, %s): %s", mode, strings.Join(args, " "))
		out, e := runTick(ctx, work, ff, args, func(el time.Duration) {
			progress(3, 90+int(el.Seconds()/6)%6, fmt.Sprintf("מאחד ומייצא (%d שניות)", int(el.Seconds())))
		})
		if (e != nil || !exists(tmpOut)) && !isImg && len(enc) > 0 && enc[1] == "h264_nvenc" {
			logf("nvenc failed, retrying with x264: %s", tail(out))
			os.Remove(tmpOut)
			out, e = runTick(ctx, work, ff, buildArgs(mode, x264), func(el time.Duration) {
				progress(3, 90+int(el.Seconds()/6)%6, fmt.Sprintf("מאחד ומייצא (%d שניות)", int(el.Seconds())))
			})
		}
		if e != nil || !exists(tmpOut) {
			logf("encode FAILED: %v | %s", e, out)
			if ctx.Err() != nil {
				fail("בוטל")
			} else {
				fail("הייצוא נכשל. " + tail(out))
			}
			return
		}
	}
	_ = encOut
	logf("encode: %.1fs", time.Since(encStart).Seconds())
	final := filepath.Join(dir, base+"_אחרי-טופלייר"+outExt)
	for i := 2; exists(final); i++ {
		final = filepath.Join(dir, fmt.Sprintf("%s_אחרי-טופלייר_%d%s", base, i, outExt))
	}
	if e := moveFile(tmpOut, final); e != nil {
		fail("לא הצלחנו לשמור את הקובץ בתיקייה של המקור")
		return
	}

	// before / after preview frames
	progress(4, 96, "מכין תצוגת לפני ואחרי")
	pv := filepath.Join(toolsDir(), "pv")
	os.RemoveAll(pv)
	os.MkdirAll(pv, 0755)
	vf := "scale=720:-2"
	n := "1"
	if !isImg {
		vf = "fps=8,scale=720:-2"
		n = "48"
	}
	run(ctx, work, ff, "-hide_banner", "-nostdin", "-y", "-i", p.Path, "-vf", vf, "-frames:v", n, "-q:v", "3", filepath.Join(pv, "b_%03d.jpg"))
	run(ctx, work, ff, "-hide_banner", "-nostdin", "-y", "-i", final, "-vf", vf, "-frames:v", n, "-q:v", "3", filepath.Join(pv, "a_%03d.jpg"))
	writeDone("OK|" + final)
	setSt(func(s *Status) {
		s.State = "done"
		s.Out = final
		s.Pct = 100
		s.Stage = 5
		s.Text = "סיום. נשמר ב: " + dir
	})
}

func moveFile(a, b string) error {
	if os.Rename(a, b) == nil {
		return nil
	}
	in, err := os.Open(a)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.Create(b)
	if err != nil {
		return err
	}
	defer out.Close()
	_, err = io.Copy(out, in)
	return err
}

func tail(s string) string {
	l := strings.Split(strings.TrimSpace(s), "\n")
	if len(l) > 2 {
		l = l[len(l)-2:]
	}
	r := strings.Join(l, " | ")
	if len(r) > 220 {
		r = r[len(r)-220:]
	}
	return r
}

var doneFile string

func writeDone(t string) {
	if doneFile != "" {
		os.WriteFile(doneFile, []byte(t), 0644)
	}
}

func fmtDur(d time.Duration) string {
	s := int(d.Seconds())
	if s < 60 {
		return fmt.Sprintf("%d שניות", s)
	}
	return fmt.Sprintf("%d:%02d דקות", s/60, s%60)
}

// calibrate maps the numbers the user sees on the sliders to the real filter strength.
// The reference look (his usual values) always gives the same result; higher numbers are
// stronger, lower numbers are weaker, smoothly in both directions.
func calibrate(p *Params) {
	seg := func(v, anchorIn int, anchorEff, topEff float64) int {
		if v < 0 {
			return v
		}
		x := float64(v)
		a := float64(anchorIn)
		var e float64
		if a <= 0 {
			e = x
		} else if x <= a {
			e = x * anchorEff / a
		} else {
			e = anchorEff + (x-a)*(topEff-anchorEff)/(100-a)
		}
		return int(e + 0.5)
	}
	p.Sharpen = seg(p.Sharpen, 43, 70, 130)
	p.ReduceNoise = seg(p.ReduceNoise, 21, 100, 200)
	p.Dehalo = seg(p.Dehalo, 10, 100, 200)
	p.AddNoise = seg(p.AddNoise, 2, 3, 100)
	p.RecoverOrig = seg(p.RecoverOrig, 67, 80, 110)
}

// tailWriter keeps only the last bytes written (tool output can be huge)
type tailWriter struct {
	mu  sync.Mutex
	b   []byte
	max int
}

func (t *tailWriter) Write(p []byte) (int, error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.b = append(t.b, p...)
	if len(t.b) > t.max {
		t.b = t.b[len(t.b)-t.max:]
	}
	return len(p), nil
}
func (t *tailWriter) String() string { t.mu.Lock(); defer t.mu.Unlock(); return string(t.b) }

var nvOnce sync.Once
var nvOK bool

// nvencOK: does this machine have a working NVIDIA hardware encoder? (checked once with a tiny test encode)
func nvencOK(ff string) bool {
	nvOnce.Do(func() {
		ctx, cancel := context.WithTimeout(context.Background(), 25*time.Second)
		defer cancel()
		c := exec.CommandContext(ctx, ff, "-hide_banner", "-nostdin", "-f", "lavfi", "-i", "color=c=black:s=320x240:d=0.3", "-c:v", "h264_nvenc", "-f", "null", "-")
		hide(c)
		nvOK = c.Run() == nil
		logf("nvenc available: %v", nvOK)
	})
	return nvOK
}

// jpgComplete: a JPEG is finished when it ends with the end-of-image marker
func jpgComplete(b []byte) bool { return len(b) > 200 && b[len(b)-2] == 0xFF && b[len(b)-1] == 0xD9 }

// feedFrames streams the AI frames (000001.jpg, 000002.jpg ...) into the encoder as soon as each one is complete.
// It returns how many frames were delivered.
func feedFrames(ctx context.Context, w io.Writer, dir string, total int, aiDone <-chan struct{}) int {
	for k := 1; k <= total; k++ {
		p := filepath.Join(dir, fmt.Sprintf("%06d.jpg", k))
		for {
			if ctx.Err() != nil {
				return k - 1
			}
			finished := false
			select {
			case <-aiDone:
				finished = true
			default:
			}
			if b, err := os.ReadFile(p); err == nil && jpgComplete(b) {
				if _, e := w.Write(b); e != nil {
					return k - 1
				}
				break
			}
			if finished {
				// the AI is over and this frame is still missing / broken
				if b, err := os.ReadFile(p); err == nil && jpgComplete(b) {
					continue
				}
				return k - 1
			}
			time.Sleep(25 * time.Millisecond)
		}
	}
	return total
}

// cleanSecs turns a time value into a plain decimal ("1.5E-7" and similar break ffmpeg with "Invalid duration")
func cleanSecs(s string) (float64, bool) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, false
	}
	v, err := strconv.ParseFloat(s, 64)
	if err != nil || math.IsNaN(v) || math.IsInf(v, 0) {
		return 0, false
	}
	return v, true
}
