package main

// The local HTTP API used by the Studio window and by the After Effects panel (hidden iframe).

import (
	_ "embed"
	"encoding/json"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

//go:embed ui.html
var uiHTML []byte

// Status is what /api/ping returns.
type Status struct {
	State   string `json:"state"` // idle, running, done, error
	Text    string `json:"text"`
	Pct     int    `json:"pct"`
	Out     string `json:"out"`
	Err     string `json:"err"`
	Frames  int    `json:"frames"`
	Stage   int    `json:"stage"`
	Info    string `json:"info"`
	Name    string `json:"name"`
	Video   bool   `json:"video"`
	Warn    string `json:"warn"`
	Mode    string `json:"mode"`
	Secs    int    `json:"secs"`
	Version string `json:"version"`
}

var (
	mu       sync.Mutex
	st       = Status{State: "idle"}
	lastPing = time.Now()
	pinged   bool
	cancelFn func()
	jobJSON  = []byte("{}")
)

func setSt(f func(s *Status)) { mu.Lock(); f(&st); mu.Unlock() }
func getSt() Status           { mu.Lock(); defer mu.Unlock(); s := st; s.Version = appVersion; return s }
func setCancel(f func())      { mu.Lock(); cancelFn = f; mu.Unlock() }
func cancelJob() {
	mu.Lock()
	f := cancelFn
	mu.Unlock()
	if f != nil {
		f()
	}
}

func jsonOut(w http.ResponseWriter, v interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	json.NewEncoder(w).Encode(v)
}

func newMux() *http.ServeMux {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		w.Write(uiHTML)
	})
	mux.HandleFunc("/api/ping", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		lastPing, pinged = time.Now(), true
		mu.Unlock()
		jsonOut(w, getSt())
	})
	mux.HandleFunc("/api/job", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		b := jobJSON
		jobJSON = []byte("{}")
		mu.Unlock()
		w.Header().Set("Content-Type", "application/json; charset=utf-8")
		w.Write(b)
	})
	mux.HandleFunc("/api/pick", func(w http.ResponseWriter, r *http.Request) {
		jsonOut(w, map[string]string{"path": pickFile()})
	})
	mux.HandleFunc("/api/upload", func(w http.ResponseWriter, r *http.Request) {
		name := filepath.Base(r.URL.Query().Get("name"))
		name = strings.Map(func(c rune) rune { // characters Windows does not allow in file names
			if strings.ContainsRune(`<>:"/\|?*`, c) || c < 32 {
				return '_'
			}
			return c
		}, name)
		if name == "" || name == "." || name == ".." {
			name = "file"
		}
		dir := filepath.Join(toolsDir(), "uploads")
		os.RemoveAll(dir)
		os.MkdirAll(dir, 0755)
		p := filepath.Join(dir, name)
		f, err := os.Create(p)
		if err != nil {
			jsonOut(w, map[string]string{"error": "שמירת הקובץ נכשלה"})
			return
		}
		_, err = io.Copy(f, r.Body)
		f.Close()
		if err != nil {
			jsonOut(w, map[string]string{"error": "העלאת הקובץ נקטעה"})
			return
		}
		jsonOut(w, map[string]string{"path": p})
	})
	mux.HandleFunc("/api/check", func(w http.ResponseWriter, r *http.Request) {
		var p Params
		json.NewDecoder(r.Body).Decode(&p)
		fi, err := os.Stat(p.Path)
		jsonOut(w, map[string]bool{"ok": err == nil && !fi.IsDir()})
	})
	mux.HandleFunc("/api/start", func(w http.ResponseWriter, r *http.Request) {
		var p Params
		if json.NewDecoder(r.Body).Decode(&p) != nil || p.Path == "" {
			jsonOut(w, map[string]string{"error": "לא נבחר קובץ"})
			return
		}
		if _, err := os.Stat(p.Path); err != nil {
			jsonOut(w, map[string]string{"error": "הקובץ לא נמצא"})
			return
		}
		mu.Lock()
		if st.State == "running" {
			mu.Unlock()
			jsonOut(w, map[string]string{"error": "כבר רץ עיבוד. חכה שיסתיים או עצור אותו"})
			return
		}
		st = Status{State: "running", Text: "מתחיל", Name: filepath.Base(p.Path)}
		mu.Unlock()
		go runJob(p)
		jsonOut(w, map[string]string{"ok": "1"})
	})
	mux.HandleFunc("/api/cancel", func(w http.ResponseWriter, r *http.Request) {
		cancelJob()
		jsonOut(w, map[string]string{"ok": "1"})
	})
	mux.HandleFunc("/api/open", func(w http.ResponseWriter, r *http.Request) {
		if s := getSt(); s.Out != "" {
			openPath(s.Out, r.URL.Query().Get("play") != "1")
		}
		jsonOut(w, map[string]string{"ok": "1"})
	})
	mux.HandleFunc("/api/quit", func(w http.ResponseWriter, r *http.Request) {
		jsonOut(w, map[string]string{"ok": "1"})
		go func() { time.Sleep(200 * time.Millisecond); shutdown() }()
	})
	mux.Handle("/pv/", http.StripPrefix("/pv/", noCache(http.FileServer(http.Dir(filepath.Join(toolsDir(), "pv"))))))
	return mux
}

func noCache(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		h.ServeHTTP(w, r)
	})
}

func shutdown() {
	cancelJob()
	time.Sleep(150 * time.Millisecond)
	os.Exit(0)
}
