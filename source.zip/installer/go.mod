module pps_setup

go 1.22
