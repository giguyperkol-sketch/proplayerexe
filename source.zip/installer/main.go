package main

import (
	_ "embed"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
)

//go:embed ProPlayerStudio.exe
var app []byte

var (
	user32 = syscall.NewLazyDLL("user32.dll")
	msgBox = user32.NewProc("MessageBoxW")
)

func u16(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func box(t string, f uintptr) uintptr {
	r, _, _ := msgBox.Call(0, uintptr(unsafe.Pointer(u16(t))), uintptr(unsafe.Pointer(u16("ProPlayer Studio"))), f)
	return r
}
func ps(script string) {
	c := exec.Command("powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	c.Run()
}
func reg(args ...string) {
	c := exec.Command("reg", args...)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	c.Run()
}
func q(s string) string { return "'" + strings.ReplaceAll(s, "'", "''") + "'" }

const uk = `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\ProPlayerStudio`

func main() {
	dir := filepath.Join(os.Getenv("LOCALAPPDATA"), "Programs", "ProPlayer Studio")
	start := filepath.Join(os.Getenv("APPDATA"), `Microsoft\Windows\Start Menu\Programs`)
	desk := filepath.Join(os.Getenv("USERPROFILE"), "Desktop")
	if len(os.Args) > 1 && os.Args[1] == "/uninstall" {
		if box("להסיר את ProPlayer Studio מהמחשב?", 0x24) != 6 {
			return
		}
		exec.Command("taskkill", "/F", "/IM", "ProPlayerStudio.exe").Run()
		os.Remove(filepath.Join(desk, "ProPlayer Studio.lnk"))
		os.Remove(filepath.Join(start, "ProPlayer Studio.lnk"))
		os.RemoveAll(filepath.Join(os.Getenv("LOCALAPPDATA"), "ProPlayer Studio"))
		reg("delete", uk, "/f")
		// the uninstaller cannot delete itself while running: schedule it
		ps("Start-Sleep 2; Remove-Item -Recurse -Force " + q(dir))
		box("התוכנה הוסרה.", 0x40)
		return
	}
	if box("להתקין את ProPlayer Studio?", 0x24) != 6 {
		return
	}
	exec.Command("taskkill", "/F", "/IM", "ProPlayerStudio.exe").Run()
	if err := os.MkdirAll(dir, 0755); err != nil {
		box("ההתקנה נכשלה: "+err.Error(), 0x10)
		return
	}
	exe := filepath.Join(dir, "ProPlayerStudio.exe")
	if err := os.WriteFile(exe, app, 0755); err != nil {
		box("ההתקנה נכשלה: "+err.Error(), 0x10)
		return
	}
	// uninstaller = copy of this setup
	if me, err := os.Executable(); err == nil {
		if in, err := os.Open(me); err == nil {
			if out, err := os.Create(filepath.Join(dir, "Uninstall.exe")); err == nil {
				io.Copy(out, in)
				out.Close()
			}
			in.Close()
		}
	}
	mk := func(lnk string) {
		ps("$s=(New-Object -ComObject WScript.Shell).CreateShortcut(" + q(lnk) + "); $s.TargetPath=" + q(exe) + "; $s.WorkingDirectory=" + q(dir) + "; $s.IconLocation=" + q(exe) + "; $s.Save()")
	}
	mk(filepath.Join(desk, "ProPlayer Studio.lnk"))
	mk(filepath.Join(start, "ProPlayer Studio.lnk"))
	reg("add", uk, "/v", "DisplayName", "/t", "REG_SZ", "/d", "ProPlayer Studio", "/f")
	reg("add", uk, "/v", "UninstallString", "/t", "REG_SZ", "/d", `"`+filepath.Join(dir, "Uninstall.exe")+`" /uninstall`, "/f")
	reg("add", uk, "/v", "InstallLocation", "/t", "REG_SZ", "/d", dir, "/f")
	reg("add", uk, "/v", "Publisher", "/t", "REG_SZ", "/d", "ProPlayer", "/f")
	if box("ההתקנה הסתיימה.\nנוצר קיצור דרך על שולחן העבודה.\n\nלפתוח את התוכנה עכשיו?", 0x24) == 6 {
		exec.Command(exe).Start()
	}
}
