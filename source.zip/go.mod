module proplayerstudio
go 1.21
