//go:build !windows

package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
)

// These tests run the whole pipeline (frame extraction, "AI" step, filters, encode) with the real ffmpeg
// and a stand-in for the AI engine, for every model and every slider extreme.
func TestPipeline(t *testing.T) {
	ff, err := exec.LookPath("ffmpeg")
	if err != nil {
		t.Skip("ffmpeg not installed")
	}
	// copy the stand-in engine and make it executable (uploading through the GitHub web page drops the executable bit)
	body, err := os.ReadFile("testdata/fakeesr.sh")
	if err != nil {
		t.Fatal(err)
	}
	fake := filepath.Join(t.TempDir(), "fakeesr.sh")
	if err := os.WriteFile(fake, body, 0755); err != nil {
		t.Fatal(err)
	}
	t.Setenv("PPS_HOME", t.TempDir())
	t.Setenv("PPS_FFMPEG", ff)
	t.Setenv("PPS_ESRGAN", fake)
	os.MkdirAll(toolsDir(), 0755)

	src := t.TempDir()
	mk := func(name string, args ...string) string {
		p := filepath.Join(src, name)
		a := append([]string{"-loglevel", "error", "-y"}, args...)
		a = append(a, p)
		if out, e := exec.Command(ff, a...).CombinedOutput(); e != nil {
			t.Fatalf("making %s: %v %s", name, e, out)
		}
		return p
	}
	landscape := mk("land.mp4", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=30:duration=0.4", "-f", "lavfi", "-i", "sine=frequency=440:duration=0.4", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest")
	portrait := mk("port.mp4", "-f", "lavfi", "-i", "testsrc2=size=360x640:rate=30:duration=0.3", "-c:v", "libx264", "-pix_fmt", "yuv420p")
	hfr := mk("hfr.mp4", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=120:duration=0.1", "-c:v", "libx264", "-pix_fmt", "yuv420p")
	still := mk("still.png", "-f", "lavfi", "-i", "testsrc2=size=640x360", "-frames:v", "1")

	normal := Params{Revert: 25, Recover: 10, Sharpen: 10, ReduceNoise: 5, AntiAlias: 5, RecoverOrig: 15}
	strong := Params{Revert: 60, Recover: 45, Sharpen: 35, ReduceNoise: 5, Dehalo: 10, AntiAlias: 30, RecoverOrig: 50}
	psycho := Params{Revert: 70, Recover: 55, Sharpen: 45, ReduceNoise: 5, Dehalo: 10, AntiAlias: 35, RecoverOrig: 70, Hair: 12}
	maxed := Params{Revert: 100, Recover: 100, Sharpen: 100, ReduceNoise: 100, Dehalo: 100, AntiAlias: 100, AddNoise: 100, RecoverOrig: 100, Hair: 100}
	mined := Params{Revert: -100, Recover: -100, Sharpen: -100, ReduceNoise: -100, Dehalo: -100, AntiAlias: -100, AddNoise: -100, RecoverOrig: -100, Hair: -100}

	with := func(p Params, path, model string) Params { p.Path, p.Model = path, model; return p }
	type tc struct {
		name string
		p    Params
		w, h int // expected output size
	}
	var cases []tc
	for _, m := range []string{"realesr-animevideov3", "realesrgan-x4plus", "realesrgan-x4plus-anime"} {
		cases = append(cases,
			tc{m + " normal", with(normal, landscape, m), 1280, 720},
			tc{m + " strong", with(strong, landscape, m), 1280, 720},
			tc{m + " psycho", with(psycho, landscape, m), 1280, 720})
	}
	cases = append(cases,
		tc{"max sliders", with(maxed, landscape, "realesrgan-x4plus"), 1280, 720},
		tc{"min sliders", with(mined, landscape, "realesr-animevideov3"), 1280, 720},
		tc{"portrait", with(normal, portrait, "realesr-animevideov3"), 720, 1280},
		tc{"120fps source", with(normal, hfr, "realesr-animevideov3"), 1280, 720},
		tc{"empty model", with(normal, landscape, ""), 1280, 720},
		tc{"still image", with(strong, still, "realesrgan-x4plus"), 1280, 720})
	ex := with(normal, landscape, "realesr-animevideov3")
	ex.Ss, ex.Dur = "4.440892098500626e-16", "0.2" // numbers like this used to break ffmpeg ("Invalid duration")
	cases = append(cases, tc{"exponent time value", ex, 1280, 720})
	ilc := with(normal, landscape, "realesr-animevideov3")
	ilc.VideoType = "Interlaced"
	cases = append(cases, tc{"interlaced", ilc, 1280, 720})

	for _, c := range cases {
		c := c
		t.Run(c.name, func(t *testing.T) {
			setSt(func(s *Status) { *s = Status{State: "running"} })
			runJob(c.p)
			s := getSt()
			if s.State != "done" {
				t.Fatalf("state=%s err=%q text=%q", s.State, s.Err, s.Text)
			}
			if s.Warn != "" {
				t.Fatalf("the AI step fell back: %s", s.Warn)
			}
			out, e := exec.Command(ff, "-hide_banner", "-i", s.Out).CombinedOutput()
			_ = e
			if !strings.Contains(string(out), "x"+strconv.Itoa(c.h)) || !strings.Contains(string(out), strconv.Itoa(c.w)+"x") {
				t.Fatalf("unexpected output size: %s", string(out))
			}
			os.Remove(s.Out)
		})
	}
}
