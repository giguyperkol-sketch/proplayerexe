//go:build !windows

package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
)

// These tests run the whole pipeline (frame extraction, "AI" step, filters, encode) with the real ffmpeg
// and a stand-in for the AI engine, for every model and every slider extreme.
func TestPipeline(t *testing.T) {
	ff, err := exec.LookPath("ffmpeg")
	if err != nil {
		t.Skip("ffmpeg not installed")
	}
	// copy the stand-in engine and make it executable (uploading through the GitHub web page drops the executable bit)
	body, err := os.ReadFile("testdata/fakeesr.sh")
	if err != nil {
		t.Fatal(err)
	}
	fake := filepath.Join(t.TempDir(), "fakeesr.sh")
	if err := os.WriteFile(fake, body, 0755); err != nil {
		t.Fatal(err)
	}
	t.Setenv("PPS_HOME", t.TempDir())
	t.Setenv("PPS_FFMPEG", ff)
	t.Setenv("PPS_ESRGAN", fake)
	os.MkdirAll(toolsDir(), 0755)

	src := t.TempDir()
	mk := func(name string, args ...string) string {
		p := filepath.Join(src, name)
		a := append([]string{"-loglevel", "error", "-y"}, args...)
		a = append(a, p)
		if out, e := exec.Command(ff, a...).CombinedOutput(); e != nil {
			t.Fatalf("making %s: %v %s", name, e, out)
		}
		return p
	}
	landscape := mk("land.mp4", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=30:duration=0.4", "-f", "lavfi", "-i", "sine=frequency=440:duration=0.4", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest")
	portrait := mk("port.mp4", "-f", "lavfi", "-i", "testsrc2=size=360x640:rate=30:duration=0.3", "-c:v", "libx264", "-pix_fmt", "yuv420p")
	hfr := mk("hfr.mp4", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=120:duration=0.1", "-c:v", "libx264", "-pix_fmt", "yuv420p")
	still := mk("still.png", "-f", "lavfi", "-i", "testsrc2=size=640x360", "-frames:v", "1")

	normal := Params{Revert: 25, Recover: 10, Sharpen: 10, ReduceNoise: 5, AntiAlias: 5, RecoverOrig: 15}
	strong := Params{Revert: 60, Recover: 45, Sharpen: 35, ReduceNoise: 5, Dehalo: 10, AntiAlias: 30, RecoverOrig: 50}
	psycho := Params{Revert: 70, Recover: 55, Sharpen: 45, ReduceNoise: 5, Dehalo: 10, AntiAlias: 35, RecoverOrig: 70, Hair: 12}
	maxed := Params{Revert: 100, Recover: 100, Sharpen: 100, ReduceNoise: 100, Dehalo: 100, AntiAlias: 100, AddNoise: 100, RecoverOrig: 100, Hair: 100}
	mined := Params{Revert: -100, Recover: -100, Sharpen: -100, ReduceNoise: -100, Dehalo: -100, AntiAlias: -100, AddNoise: -100, RecoverOrig: -100, Hair: -100}

	with := func(p Params, path, model string) Params { p.Path, p.Model = path, model; return p }
	type tc struct {
		name string
		p    Params
		w, h int // expected output size
	}
	var cases []tc
	for _, m := range []string{"fast", "quality", "max", "anime"} {
		cases = append(cases,
			tc{m + " normal", with(normal, landscape, m), 1280, 720},
			tc{m + " strong", with(strong, landscape, m), 1280, 720},
			tc{m + " psycho", with(psycho, landscape, m), 1280, 720})
	}
	cases = append(cases,
		tc{"max sliders", with(maxed, landscape, "max"), 1280, 720},
		tc{"min sliders", with(mined, landscape, "fast"), 1280, 720},
		tc{"portrait", with(normal, portrait, "quality"), 720, 1280},
		tc{"120fps source", with(normal, hfr, "fast"), 1280, 720},
		tc{"empty model", with(normal, landscape, ""), 1280, 720},
		tc{"older panel model name", with(normal, landscape, "realesrgan-x4plus"), 1280, 720},
		tc{"still image", with(strong, still, "quality"), 1280, 720})
	ex := with(normal, landscape, "fast")
	ex.Ss, ex.Dur = "4.440892098500626e-16", "0.2" // numbers like this used to break ffmpeg ("Invalid duration")
	cases = append(cases, tc{"exponent time value", ex, 1280, 720})
	ilc := with(normal, landscape, "fast")
	ilc.VideoType = "Interlaced"
	cases = append(cases, tc{"interlaced", ilc, 1280, 720})

	for _, c := range cases {
		c := c
		t.Run(c.name, func(t *testing.T) {
			setSt(func(s *Status) { *s = Status{State: "running"} })
			runJob(c.p)
			s := getSt()
			if s.State != "done" {
				t.Fatalf("state=%s err=%q text=%q", s.State, s.Err, s.Text)
			}
			if s.Warn != "" {
				t.Fatalf("the AI step fell back: %s", s.Warn)
			}
			out, e := exec.Command(ff, "-hide_banner", "-i", s.Out).CombinedOutput()
			_ = e
			if !strings.Contains(string(out), "x"+strconv.Itoa(c.h)) || !strings.Contains(string(out), strconv.Itoa(c.w)+"x") {
				t.Fatalf("unexpected output size: %s", string(out))
			}
			if s.Mode != modeFor(c.p.Model).Key {
				t.Fatalf("mode %q, expected %q", s.Mode, modeFor(c.p.Model).Key)
			}
			os.Remove(s.Out)
		})
	}
}

// The bundled network must be a complete ncnn model: every layer's weights present in the .bin.
func TestBundledModel(t *testing.T) {
	par, err := bundledModels.ReadFile("models/realesr-general-x4v3.param")
	if err != nil {
		t.Fatal(err)
	}
	bin, _ := bundledModels.ReadFile("models/realesr-general-x4v3.bin")
	need := 0
	for _, l := range strings.Split(string(par), "\n")[2:] {
		f := strings.Fields(l)
		if len(f) == 0 {
			continue
		}
		kv := map[string]int{}
		for _, x := range f {
			if i := strings.Index(x, "="); i > 0 {
				kv[x[:i]], _ = strconv.Atoi(x[i+1:])
			}
		}
		switch f[0] {
		case "Convolution":
			need += 4 + 2*kv["6"] + 4*kv["0"] // fp16 weights with their tag, fp32 bias
		case "PReLU":
			need += 4 * kv["0"]
		}
	}
	if need != len(bin) {
		t.Fatalf("model weights: need %d bytes, the .bin has %d", need, len(bin))
	}
}

func TestInstallModels(t *testing.T) {
	d := t.TempDir()
	if err := installModels(d); err != nil {
		t.Fatal(err)
	}
	for _, n := range []string{"realesr-general-x4v3.param", "realesr-general-x4v3.bin"} {
		if !exists(filepath.Join(d, n)) {
			t.Fatalf("%s was not installed", n)
		}
	}
}
