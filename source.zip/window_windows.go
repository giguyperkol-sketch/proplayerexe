//go:build windows

package main

// The Studio window: a real Windows window (own icon, dark gold title bar, taskbar entry) that hosts
// the interface with Microsoft WebView2, the engine built into Windows 10/11. No browser is opened.

import (
	"os"
	"path/filepath"
	"runtime"
	"syscall"
	"time"
	"unsafe"

	webview2 "github.com/jchv/go-webview2"
	"github.com/jchv/go-webview2/webviewloader"
)

// The window must live on the main OS thread.
func init() { runtime.LockOSThread() }

// iconID is the icon group in rsrc_windows_amd64.syso (resource 1 is the manifest).
const iconID = 2

var mainHwnd uintptr

var (
	dwmapi                 = syscall.NewLazyDLL("dwmapi.dll")
	procDwmSetWindowAttrib = dwmapi.NewProc("DwmSetWindowAttribute")
	procGetDpiForSystem    = user32.NewProc("GetDpiForSystem")
	procGetSystemMetrics   = user32.NewProc("GetSystemMetrics")
	procLoadImageW         = user32.NewProc("LoadImageW")
	procSendMessageW       = user32.NewProc("SendMessageW")
	procSetWindowPos       = user32.NewProc("SetWindowPos")
	procGetModuleHandleW   = syscall.NewLazyDLL("kernel32.dll").NewProc("GetModuleHandleW")
)

func dpiScale() float64 {
	if procGetDpiForSystem.Find() == nil {
		if d, _, _ := procGetDpiForSystem.Call(); d >= 96 {
			return float64(d) / 96
		}
	}
	return 1
}

// styleWindow: dark title bar with the Studio colors (Windows 11; Windows 10 gets the dark bar) and crisp icons.
func styleWindow(hwnd uintptr) {
	if procDwmSetWindowAttrib.Find() == nil {
		set := func(attr uintptr, v uint32) {
			procDwmSetWindowAttrib.Call(hwnd, attr, uintptr(unsafe.Pointer(&v)), 4)
		}
		set(20, 1)          // DWMWA_USE_IMMERSIVE_DARK_MODE
		set(19, 1)          // the same attribute on older Windows 10 builds
		set(35, 0x000B0D10) // DWMWA_CAPTION_COLOR  #100D0B
		set(36, 0x00A5D6EA) // DWMWA_TEXT_COLOR     #EAD6A5 (gold)
		set(34, 0x002D363A) // DWMWA_BORDER_COLOR   #3A362D
	}
	hinst, _, _ := procGetModuleHandleW.Call(0)
	s := dpiScale()
	for _, ic := range []struct {
		which uintptr
		size  int
	}{{0, int(16 * s)}, {1, int(32 * s)}} { // ICON_SMALL, ICON_BIG
		h, _, _ := procLoadImageW.Call(hinst, iconID, 1, uintptr(ic.size), uintptr(ic.size), 0)
		if h != 0 {
			procSendMessageW.Call(hwnd, 0x0080, ic.which, h) // WM_SETICON
		}
	}
}

// runWindow opens the Studio window and blocks until it is closed. false = WebView2 is not available.
func runWindow(url string) bool {
	if v, err := webviewloader.GetInstalledVersion(); err != nil || v == "" {
		logf("WebView2 runtime not found (%v), using the browser window instead", err)
		return false
	}
	// no white flash while the page loads: the window starts in the Studio background color
	os.Setenv("WEBVIEW2_DEFAULT_BACKGROUND_COLOR", "FF0E0D0B")
	s := dpiScale()
	sw, _, _ := procGetSystemMetrics.Call(0) // SM_CXSCREEN
	sh, _, _ := procGetSystemMetrics.Call(1) // SM_CYSCREEN
	w, h := int(1320*s), int(860*s)
	if int(sw) > 0 && w > int(sw)*92/100 {
		w = int(sw) * 92 / 100
	}
	if int(sh) > 0 && h > int(sh)*88/100 {
		h = int(sh) * 88 / 100
	}
	wv := webview2.NewWithOptions(webview2.WebViewOptions{
		AutoFocus: true,
		DataPath:  filepath.Join(toolsDir(), "webview"),
		WindowOptions: webview2.WindowOptions{
			Title:  "ProPlayer Studio",
			Width:  uint(w),
			Height: uint(h),
			IconId: iconID,
			Center: true,
		},
	})
	if wv == nil {
		logf("WebView2 is not available, using the browser window instead")
		return false
	}
	mainHwnd = uintptr(wv.Window())
	styleWindow(mainHwnd)
	wv.SetSize(int(980*s), int(640*s), webview2.HintMin)
	// redraw the frame so the new title bar colors show immediately
	procSetWindowPos.Call(mainHwnd, 0, 0, 0, 0, 0, 0x0001|0x0002|0x0004|0x0020) // NOSIZE|NOMOVE|NOZORDER|FRAMECHANGED
	wv.Navigate(url + "?app=1")
	if os.Getenv("PPS_WINDOW_TEST") == "1" { // CI check: close the window by itself after a few seconds
		go func() { time.Sleep(8 * time.Second); wv.Dispatch(wv.Terminate) }()
	}
	wv.Run()
	return true
}
