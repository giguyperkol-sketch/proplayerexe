package main

// Helpers around the external tools (ffmpeg, the AI engine): running them hidden, reading their
// output, probing media files and small file utilities.

import (
	"context"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

var logMu sync.Mutex

// logf appends a line to studio-log.txt (stage timings, exact commands, tool errors),
// so any failure on a user's machine can be diagnosed afterwards.
func logf(format string, a ...interface{}) {
	logMu.Lock()
	defer logMu.Unlock()
	p := filepath.Join(toolsDir(), "studio-log.txt")
	if fi, err := os.Stat(p); err == nil && fi.Size() > 2<<20 {
		os.Rename(p, p+".old") // keep the log small
	}
	f, err := os.OpenFile(p, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	fmt.Fprintf(f, "%s  %s\n", time.Now().Format("2006-01-02 15:04:05"), fmt.Sprintf(format, a...))
}

func exists(p string) bool { _, e := os.Stat(p); return e == nil }

// tailWriter keeps only the last bytes written (tool output can be huge).
type tailWriter struct {
	mu  sync.Mutex
	b   []byte
	max int
}

func (t *tailWriter) Write(p []byte) (int, error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.b = append(t.b, p...)
	if len(t.b) > t.max {
		t.b = t.b[len(t.b)-t.max:]
	}
	return len(p), nil
}

func (t *tailWriter) String() string { t.mu.Lock(); defer t.mu.Unlock(); return string(t.b) }

// run starts a tool hidden (no console window) and returns the end of its output.
func run(ctx context.Context, dir, name string, args ...string) (string, error) {
	c := exec.CommandContext(ctx, name, args...)
	c.Dir = dir
	hide(c)
	out := &tailWriter{max: 16 << 10}
	c.Stdout, c.Stderr = out, out
	err := c.Run()
	return out.String(), err
}

// runTick is run() plus a callback every 700ms while the tool works (for progress text).
func runTick(ctx context.Context, dir, name string, args []string, f func(el time.Duration)) (string, error) {
	type res struct {
		o string
		e error
	}
	ch := make(chan res, 1)
	go func() { o, e := run(ctx, dir, name, args...); ch <- res{o, e} }()
	t0 := time.Now()
	tk := time.NewTicker(700 * time.Millisecond)
	defer tk.Stop()
	for {
		select {
		case r := <-ch:
			return r.o, r.e
		case <-tk.C:
			f(time.Since(t0))
		}
	}
}

// tail returns the last two lines of a tool's output, shortened for the UI.
func tail(s string) string {
	l := strings.Split(strings.TrimSpace(s), "\n")
	if len(l) > 2 {
		l = l[len(l)-2:]
	}
	r := strings.TrimSpace(strings.Join(l, " | "))
	if len(r) > 220 {
		r = r[len(r)-220:]
	}
	return r
}

type probeInfo struct {
	W, H int
	Fps  float64
	Dur  float64
}

var (
	reSize = regexp.MustCompile(`Video:.*?[ ,](\d{2,5})x(\d{2,5})`)
	reFps  = regexp.MustCompile(`([\d.]+) fps`)
	reDur  = regexp.MustCompile(`Duration: (\d+):(\d+):([\d.]+)`)
)

// probe reads size, frame rate and duration from ffmpeg's banner.
func probe(ctx context.Context, ff, file string) probeInfo {
	out, _ := run(ctx, "", ff, "-hide_banner", "-nostdin", "-i", file)
	var p probeInfo
	if m := reSize.FindStringSubmatch(out); m != nil {
		p.W, _ = strconv.Atoi(m[1])
		p.H, _ = strconv.Atoi(m[2])
	}
	if m := reFps.FindStringSubmatch(out); m != nil {
		p.Fps, _ = strconv.ParseFloat(m[1], 64)
	}
	if m := reDur.FindStringSubmatch(out); m != nil {
		h, _ := strconv.Atoi(m[1])
		mi, _ := strconv.Atoi(m[2])
		se, _ := strconv.ParseFloat(m[3], 64)
		p.Dur = float64(h*3600+mi*60) + se
	}
	return p
}

var (
	nvOnce sync.Once
	nvOK   bool
)

// nvencOK: does this machine have a working NVIDIA hardware encoder? (checked once with a tiny test encode)
func nvencOK(ff string) bool {
	nvOnce.Do(func() {
		ctx, cancel := context.WithTimeout(context.Background(), 25*time.Second)
		defer cancel()
		_, err := run(ctx, "", ff, "-hide_banner", "-nostdin", "-f", "lavfi", "-i", "color=c=black:s=320x240:d=0.3", "-c:v", "h264_nvenc", "-f", "null", "-")
		nvOK = err == nil
		logf("nvenc available: %v", nvOK)
	})
	return nvOK
}

func countFiles(dir string) int {
	es, _ := os.ReadDir(dir)
	return len(es)
}

// jpgComplete: a JPEG is finished once it ends with the end-of-image marker.
func jpgComplete(b []byte) bool { return len(b) > 200 && b[len(b)-2] == 0xFF && b[len(b)-1] == 0xD9 }

// feedFrames streams the AI frames (000001.jpg, 000002.jpg ...) into the encoder as soon as each
// one is complete, so encoding runs at the same time as the AI. It returns how many were delivered.
func feedFrames(ctx context.Context, w io.Writer, dir string, total int, aiDone <-chan struct{}) int {
	for k := 1; k <= total; k++ {
		p := filepath.Join(dir, fmt.Sprintf("%06d.jpg", k))
		for {
			if ctx.Err() != nil {
				return k - 1
			}
			finished := false
			select {
			case <-aiDone:
				finished = true
			default:
			}
			if b, err := os.ReadFile(p); err == nil && jpgComplete(b) {
				if _, e := w.Write(b); e != nil {
					return k - 1
				}
				break
			}
			if finished {
				return k - 1 // the AI is over and this frame is missing or broken
			}
			time.Sleep(20 * time.Millisecond)
		}
	}
	return total
}

func moveFile(a, b string) error {
	if os.Rename(a, b) == nil {
		return nil
	}
	in, err := os.Open(a)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.Create(b)
	if err != nil {
		return err
	}
	if _, err = io.Copy(out, in); err != nil {
		out.Close()
		os.Remove(b)
		return err
	}
	return out.Close()
}

func fmtDur(d time.Duration) string {
	s := int(d.Seconds())
	if s < 60 {
		return fmt.Sprintf("%d שניות", s)
	}
	return fmt.Sprintf("%d:%02d דקות", s/60, s%60)
}

// cleanSecs parses a time value from the panel. Numbers like "1.5E-7" broke ffmpeg ("Invalid duration").
func cleanSecs(s string) (float64, bool) {
	v, err := strconv.ParseFloat(strings.TrimSpace(s), 64)
	if err != nil || v != v || v > 1e7 || v < -1e7 {
		return 0, false
	}
	return v, true
}
