package main

// ffmpeg filter chains: what happens to the frames before the AI (clean-up, resize to the AI input)
// and after it (noise, sharpening, grain). The slider numbers map to filter strengths in calibrate().

import (
	"fmt"
	"math"
	"strings"
)

// preFilters runs before the AI, at the source size, and ends with the resize to the AI input size.
func preFilters(p Params, fps float64, origW, origH, inW, inH int) []string {
	var f []string
	if fps > 60.5 {
		f = append(f, "fps=60")
	}
	switch p.VideoType {
	case "Interlaced":
		f = append(f, "yadif=mode=send_frame:parity=auto:deint=all")
	case "Interlaced Progressive":
		f = append(f, "yadif=mode=send_frame:parity=auto:deint=interlaced")
	}
	if p.Revert > 0 {
		rv := float64(p.Revert) / 100
		a := 0.098 + rv*0.12
		kind := "weak"
		if p.Revert > 40 {
			kind = "strong"
		}
		f = append(f, fmt.Sprintf("deblock=filter=%s:block=8:alpha=%.3f:beta=%.3f:gamma=%.3f:delta=%.3f", kind, a, a, a*0.6, a*0.6))
	}
	if p.Revert < 0 { // the opposite of Revert Compression: a blocky, compressed look
		k := 1 + float64(-p.Revert)/100
		f = append(f, fmt.Sprintf("scale=%d:%d:flags=area,scale=%d:%d:flags=neighbor", even(float64(origW)/k)+2, even(float64(origH)/k)+2, even(float64(origW)), even(float64(origH))))
	}
	if p.Dehalo < 0 { // stronger edge halos
		f = append(f, fmt.Sprintf("unsharp=7:7:%.2f:7:7:0", math.Min(5, float64(-p.Dehalo)/100*1.5)))
	}
	if p.AntiAlias < 0 {
		f = append(f, fmt.Sprintf("unsharp=3:3:%.2f:3:3:0", math.Min(5, float64(-p.AntiAlias)/100*2)))
	}
	if p.Dehalo > 0 {
		d := float64(p.Dehalo) / 100
		f = append(f, fmt.Sprintf("bilateral=sigmaS=%.2f:sigmaR=%.2f", 0.6+d*0.9, 0.05+d*0.08))
	}
	if p.AntiAlias > 0 {
		f = append(f, fmt.Sprintf("gblur=sigma=%.2f", 0.1+float64(p.AntiAlias)/100*0.5))
	}
	if inW != origW || inH != origH {
		flags := "lanczos"
		if inW < origW {
			flags = "area+accurate_rnd" // clean downscale (no ringing)
		}
		f = append(f, fmt.Sprintf("scale=%d:%d:flags=%s", inW, inH, flags))
	}
	return f
}

// postFilters runs after the AI, at the final size. pfmt is the working pixel format.
func postFilters(p Params, pfmt string) string {
	var f []string
	if p.ReduceNoise < 0 {
		f = append(f, fmt.Sprintf("noise=alls=%d", int(math.Min(60, float64(-p.ReduceNoise)*0.3))))
	}
	if p.AddNoise < 0 {
		an := float64(-p.AddNoise) / 100
		f = append(f, fmt.Sprintf("hqdn3d=%.2f:%.2f:%.2f:%.2f", an*8, an*6, an*12, an*9))
	}
	if p.ReduceNoise > 0 {
		rn := float64(p.ReduceNoise) / 100
		f = append(f, fmt.Sprintf("hqdn3d=%.2f:%.2f:%.2f:%.2f", rn*1.8, rn*1.4, rn*3, rn*2.4))
	}
	if p.Hair != 0 {
		h := math.Min(1, math.Abs(float64(p.Hair))/100)
		// a soft mask of dark, textured areas (hair) built at quarter size
		mask := fmt.Sprintf("[hm]scale=iw/4:ih/4,format=gray,lut=y='clip((210-val)*3,0,255)*%.2f',gblur=sigma=2,scale=iw*4:ih*4,format=yuv420p[hmask]", h)
		var side string
		if p.Hair > 0 { // smooth hair: median at half size (4x cheaper)
			side = fmt.Sprintf("[hs]scale=iw/2:ih/2:flags=bilinear,median=radius=%d,scale=iw*2:ih*2:flags=bilinear[hmed]", int(1+h*3))
		} else { // the opposite: bring out texture in dark areas
			side = fmt.Sprintf("[hs]unsharp=7:7:%.2f:7:7:0[hmed]", 1+h*2.5)
		}
		f = append(f, "format=yuv420p,split=3[hb][hm][hs];"+side+";"+mask+";[hb][hmed][hmask]maskedmerge=planes=1,format="+pfmt)
	}
	// sharpening: a fine and a coarse pass, then halo-free contrast adaptive sharpening
	s, r, aa := float64(p.Sharpen)/100, float64(p.Recover)/100, float64(p.AntiAlias)/100
	if fine := math.Max(-2, math.Min(5, s*3.4+r*1.0+math.Max(0, aa)*2.0)); math.Abs(fine) > 0.01 {
		f = append(f, fmt.Sprintf("unsharp=5:5:%.2f:5:5:0", fine))
	}
	if coarse := math.Max(-2, math.Min(5, r*2.4)); math.Abs(coarse) > 0.01 {
		f = append(f, fmt.Sprintf("unsharp=11:11:%.2f:11:11:0", coarse))
	}
	if c := math.Min(1, s*0.6+r*0.5); c > 0.02 {
		f = append(f, fmt.Sprintf("cas=%.2f", c))
	}
	if p.AddNoise > 0 {
		fl := ""
		if p.AddNoise > 8 {
			fl = ":allf=t" // temporal grain is much slower, only worth it when the grain is visible
		}
		f = append(f, fmt.Sprintf("noise=alls=%d%s", int(math.Min(100, float64(p.AddNoise))), fl))
	}
	if len(f) == 0 {
		return ""
	}
	return ",format=" + pfmt + "," + strings.Join(f, ",")
}

// calibrate maps the numbers on the sliders to the real filter strength. The reference look always
// gives the same result; higher numbers are stronger, lower numbers weaker, smoothly in both directions.
func calibrate(p *Params) {
	seg := func(v, anchorIn int, anchorEff, topEff float64) int {
		if v < 0 {
			return v
		}
		x, a := float64(v), float64(anchorIn)
		var e float64
		switch {
		case a <= 0:
			e = x
		case x <= a:
			e = x * anchorEff / a
		default:
			e = anchorEff + (x-a)*(topEff-anchorEff)/(100-a)
		}
		return int(e + 0.5)
	}
	p.Sharpen = seg(p.Sharpen, 43, 70, 130)
	p.ReduceNoise = seg(p.ReduceNoise, 21, 100, 200)
	p.Dehalo = seg(p.Dehalo, 10, 100, 200)
	p.AddNoise = seg(p.AddNoise, 2, 3, 100)
	p.RecoverOrig = seg(p.RecoverOrig, 67, 80, 110)
}

func even(v float64) int {
	n := int(v+0.5) / 2 * 2
	if n < 2 {
		n = 2
	}
	return n
}

func clampInt(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}
