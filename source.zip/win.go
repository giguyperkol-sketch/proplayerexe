//go:build windows

package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"syscall"
	"unicode/utf16"
	"unsafe"
)

func hide(c *exec.Cmd) {
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
}

func toolsDir() string {
	b := os.Getenv("LOCALAPPDATA")
	if b == "" {
		b = os.TempDir()
	}
	return filepath.Join(b, "ProPlayer Studio")
}

func exeName(n string) string { return n + ".exe" }

type ofn struct {
	lStructSize                    uint32
	hwndOwner, hInstance           uintptr
	lpstrFilter, lpstrCustomFilter *uint16
	nMaxCustFilter, nFilterIndex   uint32
	lpstrFile                      *uint16
	nMaxFile                       uint32
	lpstrFileTitle                 *uint16
	nMaxFileTitle                  uint32
	lpstrInitialDir, lpstrTitle    *uint16
	Flags                          uint32
	nFileOffset, nFileExtension    uint16
	lpstrDefExt                    *uint16
	lCustData, lpfnHook            uintptr
	lpTemplateName                 *uint16
	pvReserved                     uintptr
	dwReserved, FlagsEx            uint32
}

func pickFile() string {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	filter := utf16.Encode([]rune("Video / Image\x00*.mp4;*.mov;*.mkv;*.avi;*.webm;*.m4v;*.wmv;*.png;*.jpg;*.jpeg;*.webp;*.bmp\x00All files\x00*.*\x00\x00"))
	buf := make([]uint16, 4096)
	title, _ := syscall.UTF16PtrFromString("ProPlayer Studio")
	fg, _, _ := syscall.NewLazyDLL("user32.dll").NewProc("GetForegroundWindow").Call()
	o := ofn{hwndOwner: fg, lpstrFilter: &filter[0], nFilterIndex: 1, lpstrFile: &buf[0], nMaxFile: uint32(len(buf)), lpstrTitle: title, Flags: 0x1000 | 0x800 | 0x80000 | 0x4}
	o.lStructSize = uint32(unsafe.Sizeof(o))
	r, _, _ := syscall.NewLazyDLL("comdlg32.dll").NewProc("GetOpenFileNameW").Call(uintptr(unsafe.Pointer(&o)))
	if r == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf)
}

func openWindow(url string) *exec.Cmd {
	pf := []string{os.Getenv("ProgramFiles(x86)"), os.Getenv("ProgramFiles"), os.Getenv("LOCALAPPDATA")}
	rel := []string{`Microsoft\Edge\Application\msedge.exe`, `Google\Chrome\Application\chrome.exe`}
	prof := filepath.Join(toolsDir(), "profile")
	for _, r := range rel {
		for _, p := range pf {
			if p == "" {
				continue
			}
			x := filepath.Join(p, r)
			if _, err := os.Stat(x); err == nil {
				c := exec.Command(x, "--app="+url, "--user-data-dir="+prof, "--window-size=1180,800", "--no-first-run", "--disable-features=Translate")
				if c.Start() == nil {
					return c
				}
			}
		}
	}
	exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	return nil
}

func openPath(p string, selectIt bool) {
	if selectIt {
		exec.Command("explorer", "/select,"+p).Start()
	} else {
		exec.Command("rundll32", "url.dll,FileProtocolHandler", p).Start()
	}
}
