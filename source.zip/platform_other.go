//go:build !windows

package main

// Linux / macOS stand-ins (used by the tests in CI).

import (
	"os"
	"os/exec"
	"path/filepath"
)

func hide(c *exec.Cmd) {}

func toolsDir() string {
	if d := os.Getenv("PPS_HOME"); d != "" {
		return d
	}
	return filepath.Join(os.TempDir(), "pps")
}

func exeName(n string) string     { return n }
func pickFile() string            { return os.Getenv("PPS_PICK") }
func openPath(p string, sel bool) {}
func openBrowserWindow(u string)  { println("OPEN", u) }
func runWindow(u string) bool     { return false }
